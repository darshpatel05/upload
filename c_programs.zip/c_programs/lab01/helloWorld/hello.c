#include <stdio.h>  //standard library

int main() {    //main function with no parameters and return data type int.
    printf("Hello, World!\n");  //print command the prints "Hello, World!" and "\n" is an escape sequence that creates a new line following the statement.
    printf("My name is Darsh Patel.\n");  //print command that prints my name "Darsh Patel" and uses "\n" escape sequence again.
    return 0;   //given that the function main is of the int data type, indicates that when the function is called it needs to return an integer - given that wasn't the main function of the code, we return zero by default.
}