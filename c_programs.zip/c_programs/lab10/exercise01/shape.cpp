// shape.cpp
#include "shape.h"
#include <iostream>
#include <cmath>

// TODO : Implement Shape constructors
// Parameterized Constructor
Shape::Shape(std::string name, std::string color) : name(name), color(color) {}

// TODO : Implement Shape methods
std::string Shape::getName() const {
    return name;
}

std::string Shape::getColor() const {
    return color;
}

void Shape::setName(std::string name) {
    this->name = name;
}

void Shape::setColor(std::string color) {
    this->color = color;
}

double Shape::calculateArea() const {
    return 0.0;
}
void Shape::displayInfo() const {
    std::cout << "Shape Information:" << std::endl << "  Name: " << this->name << std::endl << "  Color: " << this->color << std::endl;
}

// TODO : Implement Circle constructors
// Parameterized Constructor
Circle::Circle(std::string name, std::string color, double radius) : Shape(name, color), radius(radius) {}

// TODO : Implement Circle methods
double Circle::getRadius() const {
    return radius;
}

void Circle::setRadius(double radius) {
    this->radius = radius;
}

double Circle::calculateArea() const {
    return 3.14159265 * pow(this->radius, 2);
}

void Circle::displayInfo() const {
    std::cout << "Circle Information:" << std::endl << "  Name: " << this->name << std::endl << "  Color: " << this->color << std::endl << "  Radius: " << this->radius << std::endl;
}


// TODO : Implement Rectangle constructors
// Parameterized Constructor
Rectangle::Rectangle(std::string name, std::string color, double width, double height) : Shape(name, color), width(width), height(height) {}

// TODO : Implement Rectangle methods

double Rectangle::getWidth() const {
    return width;
}

double Rectangle::getHeight() const {
    return height;
}

void Rectangle::setWidth(double width) {
    this->width = width;
}

void Rectangle::setHeight(double hieght) {
    this->height = height;
}

double Rectangle::calculateArea() const {
    return this->width * this->height;
}

void Rectangle::displayInfo() const {
    std::cout << "Rectangle Information:" << std::endl << "  Name: " << this->name <<  std::endl << "  Color: " << this->color << std::endl << "  Width: " << this->width << std::endl << "  Height: " << this->height << std::endl;
}

