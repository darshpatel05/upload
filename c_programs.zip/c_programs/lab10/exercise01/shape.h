// shape.h
#ifndef SHAPE_H
#define SHAPE_H

#include <string>
#include <iostream>

// Base class declaration
class Shape {
// TODO : Add protected member variables for shape name and color
protected:
    std::string name, color;

public:
// TODO : Add constructor declarations
    Shape(std::string name = "Unkown", std::string color = "None");

// TODO : Add method declarations for getting and setting shape information
    // Getters
    std::string getName() const;
    std::string getColor() const;

    //Setters
    void setName(std::string name);
    void setColor(std::string color);

// TODO : Add a virtual method to calculate area
    virtual double calculateArea() const;

// TODO : Add a virtual method to display shape information
    virtual void displayInfo() const;

};

// Derived class declaration - Circle
class Circle : public Shape {
// TODO : Add private member variables specific to Circle ( radius )
private:
    double radius;

public:
// TODO : Add constructor declarations for Circle
    Circle(std::string name = "Unkown", std::string color = "None", double radius = 0);

// TODO : Add method declarations specific to Circle
    // Getters
    double getRadius() const;

    //Setters
    void setRadius(double radius);

// TODO : Override the area calculation method
    double calculateArea() const override;

// TODO : Override the display method
    void displayInfo() const override;

};

// Derived class declaration - Rectangle
class Rectangle : public Shape {
// TODO : Add private member variables specific to Rectangle (width , height)
private:
    double width, height;
public:
// TODO : Add constructor declarations for Rectangle
    Rectangle(std::string name = "Unkown", std::string color = "None", double width = 0, double height = 0);

// TODO : Add method declarations specific to Rectangle
    // Getters
    double getWidth() const;
    double getHeight() const;

    //Setters
    void setWidth(double width);
    void setHeight(double height);  

// TODO : Override the area calculation method
    double calculateArea() const override;

// TODO : Override the display method
    void displayInfo() const override;

};

#endif // SHAPE_H
