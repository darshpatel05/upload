//main.cpp
#include <iostream>
#include "shape.h"
#include <vector>

int test_base_class() {
    // Create a shape object
    Shape s("Generic Shape", "Blue");

    // Display shape information
    s.displayInfo();

    // Try to calculate area (should return 0 for generic shape)
    std::cout << "Area of generic shape: " << s.calculateArea() << std::endl;

    return 0;
}


int test_derived_classes() {
    // Create circle and rectangle objects
    Circle c("My Circle", "Red", 5.0);
    Rectangle r("My Rectangle", "Green", 4.0, 6.0);

    // Display shape information
    c.displayInfo();
    r.displayInfo();

    // Calculate and display areas
    std::cout << "Area of circle: " << c.calculateArea() << std::endl;
    std::cout << "Area of rectangle: " << r.calculateArea() << std::endl;

    return 0;
}

int test_polymorphism() {
    // Create shape pointers to derived objects
    Shape* s1 = new Circle("Circle One", "Yellow", 3.0);
    Shape* s2 = new Rectangle("Rectangle One", "Purple", 2.0, 7.0);

    // Create a vector of shape pointers
    std::vector<Shape*> shapes;
    shapes.push_back(s1);
    shapes.push_back(s2);

    // Display all shapes using polymorphism
    std::cout << "Displaying shapes polymorphically:" << std::endl;
    for (Shape* shape : shapes) {
        shape->displayInfo();
        std::cout << "Area: " << shape->calculateArea() << std::endl;
        std::cout << "---------------------------------------------" << std::endl;
    }

    // Clean up
    delete s1;
    delete s2;

    return 0;
}



int main() {
    // Create base and derived objects
    Shape baseShape("Base Shape", "White");
    Circle circle("Red Circle", "Red", 4.0);
    Rectangle rectangle("Blue Rectangle", "Blue", 5.0, 3.0);

    // Test base class methods on derived objects
    std::cout << "Circle name: " << circle.getName() << std::endl;
    std::cout << "Rectangle color: " << rectangle.getColor() << std::endl;

    // Test overridden methods
    std::cout << "Base shape area: " << baseShape.calculateArea() << std::endl;
    std::cout << "Circle area: " << circle.calculateArea() << std::endl;
    std::cout << "Rectangle area: " << rectangle.calculateArea() << std::endl;

    // Test polymorphism with a vector of base class pointers
    std::vector<Shape*> shapes;
    shapes.push_back(&baseShape);
    shapes.push_back(&circle);
    shapes.push_back(&rectangle);

    std::cout << "\nPolymorphic display of all shapes:" << std::endl;
    for (Shape* s : shapes) {
        s->displayInfo();
        std::cout << "Area: " << s->calculateArea() << "\n\n";
    }
    
    std::cout << "==============================" << std::endl;
    test_base_class();
    std::cout << "==============================" << std::endl;
    test_derived_classes();
    std::cout << "==============================" << std::endl;
    test_polymorphism();
    

    return 0;
}