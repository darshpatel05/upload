#include <iostream>
#include "calculator.h"
#include <vector>

int test_function_overloading() {
    Calculator calc;

    // Test integer addition
    std::cout << "5 + 3 = " << calc.add(5, 3) << std::endl;

    // Test double addition
    std::cout << "4.5 + 2.5 = " << calc.add(4.5, 2.5) << std::endl;

    // Test string addition
    std::cout << "\"Hello\" + \"World\" = " << calc.add("Hello", "World") << std::endl;

    // Test triple integer addition
    std::cout << "1 + 2 + 3 = " << calc.add(1, 2, 3) << std::endl;

    // Test subtraction with different types
    std::cout << "10 - 4 = " << calc.subtract(10, 4) << std::endl;
    std::cout << "5.5 - 2.1 = " << calc.subtract(5.5, 2.1) << std::endl;

    // Test multiplication with different types
    std::cout << "6 * 7 = " << calc.multiply(6, 7) << std::endl;
    std::cout << "2.5 * 4.0 = " << calc.multiply(2.5, 4.0) << std::endl;

    return 0;
}

int test_runtime_polymorphism() {
    // Create device objects
    SmartPhone* phone = new SmartPhone("Galaxy S21", "Android", "Snapdragon");
    Laptop* laptop = new Laptop("Dell XPS", "Windows", "Intel i7");

    // Array of base class pointers
    DeviceInterface* devices[2] = { phone, laptop };

    // Demonstrate polymorphism through base class pointers
    std::cout << "Testing devices polymorphically:" << std::endl;
    for (int i = 0; i < 2; i++) {
        std::cout << "Device: " << devices[i]->getDeviceInfo() << std::endl;
        devices[i]->powerOn();
        devices[i]->performOperation("Run diagnostics");
        devices[i]->powerOff();
        std::cout << std::endl;
    }

    // Clean up
    delete phone;
    delete laptop;

    return 0;
}

int test_abstract_class() {
    // Cannot create instance of abstract class
    // DeviceInterface device; // Uncommenting this would cause a compilation error

    // Create concrete derived class instances
    SmartPhone phone("iPhone 13", "iOS", "A15");
    Laptop laptop("MacBook Pro", "macOS", "M1 Pro");

    // Call overridden methods via derived objects
    phone.powerOn();
    phone.performOperation("Make a call");
    phone.powerOff();

    laptop.powerOn();
    laptop.performOperation("Run code");
    laptop.powerOff();

    return 0;
}


int main() {
    // Test function overloading
    Calculator calc;

    std::cout << "Testing function overloading:" << std::endl;
    std::cout << "Integer addition: " << calc.add(10, 20) << std::endl;
    std::cout << "Double addition: " << calc.add(3.14, 2.71) << std::endl;
    std::cout << "String concatenation: " << calc.add("C++", " Polymorphism") << std::endl;
    std::cout << "Triple integer addition: " << calc.add(5, 10, 15) << std::endl;

    // Test runtime polymorphism
    std::cout << "\nTesting runtime polymorphism:" << std::endl;
    std::vector<DeviceInterface*> devices;

    devices.push_back(new SmartPhone("Pixel 6", "Android", "Tensor"));
    devices.push_back(new Laptop("ThinkPad", "Linux", "AMD Ryzen"));

    for (auto device : devices) {
        std::cout << "Device info: " << device->getDeviceInfo() << std::endl;
        device->powerOn();
        device->performOperation("Run system check");
        device->powerOff();
        std::cout << std::endl;
    }

    // Clean up
    for (auto device : devices) {
        delete device;
    }

    std::cout << "==============================" << std::endl;
    test_function_overloading();
    std::cout << "==============================" << std::endl;
    test_runtime_polymorphism();
    std::cout << "==============================" << std::endl;
    test_abstract_class();

    return 0;
}
