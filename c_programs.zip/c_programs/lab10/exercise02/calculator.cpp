#include "calculator.h"
#include <iostream>
#include <string>

// TODO: Implement Calculator methods with overloading
Calculator::Calculator() {}

int Calculator::add(int a, int b) {
    return a + b;
}

double Calculator::add(double a, double b) {
    return a + b;
}

std::string Calculator::add(const std::string& a, const std::string& b) {
    return a + b;
}

int Calculator::add(int a, int b, int c) {
    return a + b + c;
}

int Calculator::subtract(int a, int b) {
    return a -b;
}

double Calculator::subtract(double a, double b) {
    return a - b;
}

int Calculator::multiply(int a, int b) {
    return a * b;
}

double Calculator::multiply(double a, double b) {
    return a * b;
}

void Calculator::display() {
    std::cout << "Calculator functions include addition with up to 2 values of data types (double and string) and up to 3 values with data type (int), along with subtraction and multiplication with up to 2 values of data type (int and double)." << std::endl;
}

// TODO: Implement DeviceInterface methods
DeviceInterface::DeviceInterface(const std::string& name, const std::string& os, const std::string& processor) : name(name), os(os), processor(processor) {}

DeviceInterface::~DeviceInterface() {}

std::string DeviceInterface::getDeviceInfo() const {
    return this->name + " (" + this->os + ") with " + this->processor + " processor";
}

// TODO: Implement SmartPhone methods
SmartPhone::SmartPhone(const std::string& name, const std::string& os, const std::string& processor) : DeviceInterface(name, os, processor) {}

SmartPhone::~SmartPhone() {}

void SmartPhone::powerOn() {
    std::cout << this->name << " powered on" << std::endl;
}

void SmartPhone::powerOff() {
    std::cout << this->name << " powered off" << std::endl;
}

void SmartPhone::performOperation(const std::string& operation) {
    std::cout << this->name << " performing: " << operation << std::endl;
}

void SmartPhone::makeCall(const std::string& number) {
    std::cout << this->name << " making a call to " << number << std::endl;
}

// std::string SmartPhone::getDeviceInfo() const {
//     return this->name + " (" + this->os + ") with " + this->processor + " processor";
// }

// TODO: Implement Laptop methods
Laptop::Laptop(const std::string& name, const std::string& os, const std::string& processor) : DeviceInterface(name, os, processor) {}

Laptop::~Laptop() {}

void Laptop::powerOn() {
    std::cout << this->name << " powered on" << std::endl;
}

void Laptop::powerOff() {
    std::cout << this->name << " powered off" << std::endl;
}

void Laptop::performOperation(const std::string& operation) {
    std::cout << this->name << " performing: " << operation << std::endl;
}

void Laptop::runProgram(const std::string& program) {
    std::cout << this->name << " running program: " << program << std::endl;
}

// std::string Laptop::getDeviceInfo() const {
//     return this->name + " (" + this->os + ") with " + this->processor + " processor";
// }