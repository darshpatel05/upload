#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <string>
#include <iostream>

// Calculator class with method overloading
class Calculator {
public:
    Calculator();

    // TODO: Implement method overloading for add() with different parameter types
    int add(int a, int b);
    double add(double a, double b);
    std::string add(const std::string& a, const std::string& b);
    int add(int a, int b, int c);
    
    // TODO: Implement method overloading for subtract() with different parameter types
    int subtract(int a, int b);
    double subtract(double a, double b);

    // TODO: Implement method overloading for multiply() with different parameter types
    int multiply(int a, int b);
    double multiply(double a, double b);

    // TODO: Implement display() method to show calculator information
    void display();
};

// Base DeviceInterface class for runtime polymorphism
class DeviceInterface {
    protected:
        std::string name, os, processor;

    public:
        // TODO: Add constructor and destructor
        DeviceInterface(const std::string& name, const std::string& os, const std::string& processor);
        virtual ~DeviceInterface();

        // TODO: Add pure virtual methods for power on/off functionality
        virtual void powerOn() = 0;
        virtual void powerOff() = 0;

        // TODO: Add pure virtual method for performing device operations
        virtual void performOperation(const std::string& operation) = 0;

        // TODO: Add non-virtual method for getting device information
        std::string getDeviceInfo() const;

    };
    
// SmartPhone derived class
class SmartPhone : public DeviceInterface {
private:
    // TODO: Add relevant member variables
    std::string os, processor;

public:
    // TODO: Add constructor and destructor
    SmartPhone(const std::string& name, const std::string& os, const std::string& processor);
    ~SmartPhone() override;

    // TODO: Override power on/off methods
    virtual void powerOn() override;
    virtual void powerOff() override;

    // TODO: Override performOperation method
    virtual void performOperation(const std::string& operation) override;

    // TODO: Add smartphone-specific methods
    void makeCall(const std::string& number);

};

// Laptop derived class
class Laptop : public DeviceInterface {
private:
    // TODO: Add relevant member variables
    std::string os, processor;

public:
    // TODO: Add constructor and destructor
    Laptop(const std::string& name, const std::string& os, const std::string& processor);
    ~Laptop() override;

    // TODO: Override power on/off methods
    virtual void powerOn() override;
    virtual void powerOff() override;

    // TODO: Override performOperation method
    virtual void performOperation(const std::string& operation) override;

    // TODO: Add laptop-specific methods
    void runProgram(const std::string& program);

};

#endif // CALCULATOR_H
