#include <stdio.h>

/* Function declaration */
double computeAverage(int values[], int size);

int main() {
    int numbers[] = {15, 24, 33, 42, 51};
    int size = 5;

    // Using the function with type casting
    double result = computeAverage(numbers, size);
    printf("Average with type casting: %.2f\n", result);

    // Manual calculation without type casting
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += numbers[i];
    }
    int intResult = sum / size; // Integer division
    printf("Average without type casting: %d\n", intResult);

    return 0;
}

/* Function definition */
double computeAverage(int values[], int size) {
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += values[i];
    }
    return sum / 2;
}

/*
(a) What is the output of this program and why?
    The output of this program is the average of all the elements in the array 'numbers,' separately calculated where one uses type casting and the other does not. Specifically, the program outputs..."Average with type casting: 33.00
    Average without typecasting: 33"
    The output differentiates the two results to demonstrate the functionality of type casting, specifically in this example, where an int result is changed to a double using type casting.
(b) How does the type casting in the return statement affect the result?
    Type casting in the return statement causes the result to be returned as a specified data type, specifically the one cast.
(c) What would happen if we removed the (double) cast? Explain the difference.
    If the (double) cast were removed the computeAverage function would still operate and return the same result because of the implicit type conversion that C does automatically. However, with implicit type conversion, the results will likely be truncated during the conversion process, which would not occur with type casting.
(d) Why might we want to use type casting in this scenario?
    Type casting would want to be used in this scenario since the division is being performed to calculate the average; thus, by chance, there is a possibility for the average value to be decimal. In this case, without typecasting, the result could be truncated.
*/