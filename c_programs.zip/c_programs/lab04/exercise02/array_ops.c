#include <stdio.h>
#include "array_ops.h"

/*  Reverses the given array

    arr: the array to reverse
    size: the size of the given array

    Note: prints out the original array and reversed array
*/
void reverseArray(int arr[], int size){
    if(size <= 0) {
        printf("Invalid array size value!");
        return;
    }

    printf("Original Array: ");
    printArray(arr, size);

    /*
    Traverses halfway through the array, holding the element's value at each position in a temporary variable, rewriting the element's value at that position with the element opposite of the array, and setting the element's position opposite the array with the temporary value.
    */
    int temp;
    for(int i = 0; i < size / 2; i++){
        temp = arr[i];
        arr[i] = arr[size - 1 - i];
        arr[size - 1 - i] = temp;
    }

    printf("Reversed Array: ");
    printArray(arr, size);
}

/*  Finds the position of a specific element

    arr: the given array
    size: the size of the given array
    target: the element that the array is being searched for

    Returns: the position of the target element - if the target element is not found, -1 is returned

    Note: the function also formally prints the position of the element in the array
*/
int findElement(int arr[], int size, int target){
    if(size <= 0) {
        printf("Invalid array size value!");
        return;
    }

    /*
    Traverses the array, checking each element and comparing it to the target, returning its position if found.
    */
    for(int i = 0; i < size; i++){
        if(arr[i] == target) {
            printf("Found element %d at position %d\n", target, i);
            return i;
        }
    }

    /*
    Once the array has been fully traversed and the target is not found, -1 is returned.
    */
    printf("Element %d not found (-1)\n", target);
    return -1;
}

/*  Rotates a given array to the left by some specified number of positions

    arr: the array to rotate
    size: the size of the given array
    positions: the number of positions the array needs to be rotated to the left by

    Note: prints out the original array and rotated array
*/
void rotateLeft(int arr[], int size, int positions){
    if(size <= 0) {
        printf("Invalid array size value!");
        return;
    }
    if (positions >= 0 && positions < size) {
        printf("Original Array: ");
        printArray(arr, size);
        
        /*
        A temporary array of the same dimension as the original array is created. Then, the rotated version of the original array is created with the help of the temporary array, which is then used to replace the original array.
        */
        int temp[size];
        for(int i = positions; i < size; i++) {
            temp[i - positions] = arr[i];
        }
        for(int i = 0; i < positions; i++) {
            temp[size - positions + i] = arr[i];
        }
        arr = temp;

        printf("Rotated Array: ");
        printArray(arr, size);
    } else {
        printf("Position value out of bounds!");
    }
}

/*  Prints the given array

    arr: array to print
    size: size of the given array
*/
void printArray(int arr[], int size){
    if(size <= 0) {
        printf("Invalid array size value!");
        return;
    }
    for(int i = 0; i < size; i++){
        printf("%d ", arr[i]);
    }
    printf("\n");
}
