#include <stdio.h>
#include "array_ops.h"

int main(void) {
    int arr1[6] = {1, 2, 3, 4, 5, 6}, size1 = 6;
    int arr3[5] = {0, 0, 0, 0, 0}, size3 = 5;
    int arr4[1] = {4}, size4 = 1;

    if(size1 <= 0 && size3 <= 0 && size4 <= 0) {
        printf("Invalid array size value!");
        return 0;
    } else {
        // Test Case 1: even array size & out of bound positions value
        reverseArray(arr1, size1);
        findElement(arr1, size1, 3);
        findElement(arr1, size1, 0);
        rotateLeft(arr1, size1, 2);
        rotateLeft(arr1, size1, -13);
        printf("\n");

        // Test Case 2: odd array size & repetative elements
        findElement(arr3, size3, 21);
        findElement(arr3, size3, 0);
        printf("\n");

        // Test Case 5: single element array
        reverseArray(arr4, size4);
        findElement(arr4, size4, 3);
        findElement(arr4, size4, 0);
        rotateLeft(arr4, size4, 2);
        rotateLeft(arr4, size4, -1);
        printf("\n");
    }
    return 0;
}