#include <stdio.h>

// Function declarations
void reverseArray(int arr[], int size);
int findMax(int arr[], int size);
float calculateAverage(int arr[], int size);
void printArray(int arr[], int size);

int main() {
    int numbers[] = {64, 34, 25, 12, 22, 11, 90};
    int size = sizeof(numbers) / sizeof(numbers[0]);

    printf("Original array: ");
    printArray(numbers, size);

    // TODO: Call array operation functions

    reverseArray(numbers, size);
    printf("Reversed Array: ");
    printArray(numbers, size);

    printf("Max value: %d\n", findMax(numbers, size));
    
    printf("Average value: %f\n", calculateAverage(numbers, size));

    return 0;
}

/*  Reverses given array

    arr: the given array
    size: the size of the given array
*/
void reverseArray(int arr[], int size) {
    if (size >= 0) {
        int temp;
        for(int i = 0; i < size / 2; i++){
            temp = arr[i];
            arr[i] = arr[size - 1 - i];
            arr[size - 1 - i] = temp;
        }
    }
}

/*  Finds the value of the maximum element stored in an array

    arr: the given array
    size: the size of the given array

    Returns: the value of the maximum element
*/
int findMax(int arr[], int size) {
    if (size >= 0) {
        int max = arr[0];
        for(int i = 1; i < size; i++){
            if (max < arr[i]) {
                max = arr[i];
            }
        }
        return max;
    }
    printf("Invalid array size!");
}

/*  Finds the average of all the elements in an array

    arr: the given array
    size: the size of the given array

    Returns: the average value of the elements
*/
float calculateAverage(int arr[], int size) {
    if (size >= 0) {
        float sum;
        for(int i = 0; i < size; i++){
            sum += arr[i];
        }
        return sum / size;
    }
    printf("Invalid array size!");
}
/*  Prints the given arry

    arr: the given array
    size: the size of the given array
*/
void printArray(int arr[], int size) {
    if (size >= 0) {
        for(int i = 0; i < size; i++){
            printf("%d ", arr[i]);
        }
        printf("\n");
    }
}