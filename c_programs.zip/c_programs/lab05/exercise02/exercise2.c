#include <stdio.h>
#include <string.h>

// Maximum number of characters the strings should have 
#define MAX_LENGTH 100

// Function Prototypes
int pad_right(char str[MAX_LENGTH], int target_length);
int find_pattern(const char str[MAX_LENGTH], const char pattern[MAX_LENGTH], int positions[MAX_LENGTH]);

int main() {
    char str[MAX_LENGTH] = "banana";
    // pad_right(str, 9);
    char pat[MAX_LENGTH] = "ana";

    int positions[MAX_LENGTH];
    find_pattern(str, pat, positions);


    return 0;
}

/*  Adds spaces as padding at the end of a given string to reach a specific character limit

    str: given string that padding needs to be added to
    target_length: the specified character limit
*/
int pad_right(char str[MAX_LENGTH], int target_length) {
    printf("Start Padding Test:\n");
    printf("Original: %s\n", str);

    // Checks for cases where the target length is out of specific bounds
    if(target_length <= strlen(str)) {
        printf("ERROR: Specified \"target_length\" for \"pad_right\" function is less than or equal to the length of the given string!\n");
        return strlen(str);
    }
    if(target_length > MAX_LENGTH) {
        printf("ERROR: Specified \"target_length\" for \"pad_right\" function is greater that \"MAX_LENGTH\"!\n");
        return strlen(str);
    }

    // Number of spcaed that need to be added
    int diff = target_length - (int)strlen(str);

    // Concats additional spaces to the given string by a specified number of times
    for(int i = 0; i < diff; i++) {
        strcat(str, " ");
    }
    strcat(str, "\0");
    
    printf("After padding to %d: \"%s\"\n", target_length, str);
    printf("Length: %d\n", (int)strlen(str));

    return strlen(str);
}

/*  Finds the positions of the pattern string occurances in the str string

    str: string in which patterns are seached for
    pattern: string pattern that is being looked for
    positions: array in which the positions of the pattern occurnaces are going to be documented
*/
int find_pattern(const char str[MAX_LENGTH], const char pattern[MAX_LENGTH], int positions[MAX_LENGTH]) {
    int count = 0, match = 0;
    printf("%ld\n", strlen(str) - strlen(pattern));
    for(int i = 0; i < strlen(str) - strlen(pattern); i++) {
        if(str[i] == pattern[0]) {
            printf("str: %c | pat: %c\n", str[i], pattern[0]);
            while(str[match + i] == pattern[match + i]) {
                printf("strm: %c | patm: %c\n", str[match+i], pattern[match+i]);
                match++;
            }
            //printf("Pattern found\n");
            positions[count++] = i;
            match = 0;
        }
    }

    // for(int i = 0; i < 5; i++) {
    //     printf("%d ", positions[i]);
    // }

    return 0;
}