//CHATGPT LOGS (For understanding what transpose is, and how it is completed): https://chatgpt.com/share/67c2927a-9e60-8006-be4e-3056351bd8e3

#include <stdio.h>

// Maximum size for arrays and matrices
#define MAX_SIZE 5

// Function Prototypes
void reverse_array(int arr[MAX_SIZE], int size);
int count_occurrences(const int arr[MAX_SIZE], int size, int target);
void rotate_matrix(int matrix[][MAX_SIZE], int size);
void find_bounds(const int arr[MAX_SIZE], int size, int* min, int* max);

int main() {
    int arr[MAX_SIZE] = {1, 2, 3, 4, 5};
    int size = sizeof(arr) / sizeof(arr[0]);

    printf("Original Array: ");
    for(int i = 0; i < size; i ++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    printf("Reversed Array: ");
    reverse_array(arr, size);
    for(int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    int target = 1;
    printf("Number %d appears %d time(s)\n", target, count_occurrences(arr, size, target));

    int matrix[][MAX_SIZE] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

    size = sizeof(matrix[0]) / sizeof(matrix[0][0]);

    printf("Original Matrix: \n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
    rotate_matrix(matrix, 3);

    printf("Rotated Matrix: \n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

    int min, max;
    find_bounds(arr, size, &min, &max);
    
    return 0;
}

/*  Reversing the order of elements in the given array

    arr: given array to be reversed
    size: size of the given array
*/
void reverse_array(int arr[MAX_SIZE], int size) {
    // Traversing halfway though the array, and fliping the elements at each end of the array
    int temp;
    for(int i = 0; i < size / 2; i++) {
        temp = arr[i];
        arr[i] = arr[size - 1 - i];
        arr[size - 1 - i] = temp; 
    }
}

/*  Counts the occurrences of a cetain integer throughout the given array

    arr: given array to count the number of target values
    size: size of the given array
    target: integer being counted
*/
int count_occurrences(const int arr[MAX_SIZE], int size, int target) {
    // Traversing though the array, incremeting the value of count at each occurrence
    int count = 0;
    for(int i = 0; i < size; i++) {
        if(arr[i] == target) {
            count++;
        }
    }

    return count;
}

/*  Rotate the matrix 90 degrees clockwise

    matrix: given square matrix of size MAX_SIZE x MAX_SIZE
    size: size of the sides of the square matrix
*/
void rotate_matrix(int matrix[][MAX_SIZE], int size) {
    // Transposes the given matrix - flips the matrix across diagonally
    int temp;
    int temp_mat[size][size];
    for(int i = 0; i < size; i++) {
        for(int j = 0; j < size; j++){
            temp_mat[i][j] = matrix[j][i];
        }
    }
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            matrix[i][j] = temp_mat[i][j];
        }
    }


    // Traverses through the matrix and reverses the each row 
    for(int i = 0; i < size; i++) {
        for(int j = 0; j < size/2; j++){
            temp = matrix[i][j];
            matrix[i][j] = matrix[i][size - 1 - j];
            matrix[i][size - 1 - j] = temp;
        }
    }
}

/*  Finds the elements with the minimum and maximum value in the array.

    arr: given array to find min and max in
    size: size of the given array
    *min: int pointer that points to the adress of the min value
    *max: int pointer that points to the adress of the max value
*/
void find_bounds(const int arr[MAX_SIZE], int size, int* min, int* max) {
    // Determines if the size of the array is greater than "MAX_SIZE"
    if(size > MAX_SIZE) {
        printf("ERROR: Unable to complete \"find_bounds\" operation. Array size is larger than \"MAX_SIZE\"!\n");
        return;
    }

    // Min and max set to the first element, and a for loop iterates through the array to find a value eligible to replace it
    *max = arr[0];
    *min = arr[0];
    for(int i = 1; i < size; i++) {
        if(arr[i] > *max){
            *max = arr[i];
        }
        if(arr[i] < *min) {
            *min = arr[i];
        }
    }

    printf("Max = %d", *max);
    printf("Min = %d", *min);
}

