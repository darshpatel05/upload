#include <stdio.h>

float celsiusToFahrenheit(float celsius);       // function that takes in a celsius input and returns a fahrenheit output 
float fahrenheitToCelsius(float fahrenheit);    // functions that takes in a fahrenheit input and returns a celsius output
void printTemperature(float temp, char unit);   // function that prints out a formatted output of the temperature value and specifies the specific unit of measure

int main(void) {
    float tempCelsius, tempFahrenheit;  // Declaration of local temperature variables
    tempCelsius = 39;

    tempFahrenheit = celsiusToFahrenheit(tempCelsius);
    printTemperature(tempFahrenheit, 'F');
    tempCelsius = fahrenheitToCelsius(tempFahrenheit);
    printTemperature(tempCelsius, 'C');
}

float celsiusToFahrenheit(float celsius) {
    /*
    Function that takes a parameter of type float that represents a temperature value in celsius and returns the temperature in terms of fahrenheit as type float.
    */
    float fahrenheit = (celsius * 9 / 5) + 32;
    return fahrenheit;
}

float fahrenheitToCelsius(float fahrenheit) {
    /*
    Function that takes a parameter of type float that represents a temperature value in fahrenheit and returns the temperature in terms of celsius as type float.
    */
    float celsius = (fahrenheit - 32) * 5 / 9;
    return celsius;
}

void printTemperature(float temp, char unit) {
    /*
    Function that takes a parameter of type float that represents the temperature value and a parameter of type char that represents the unit of measure - so that the information can be properly formatted and printed out as an output.
    */
    if (unit == 'C' || unit == 'F') {
        printf("%.1f deg %c\n", temp, unit);
    } else {
        printf("Invalid temperature unit '%c', please use either 'C'-celsius or 'F'-farenheit\n", unit);
    }
}
    