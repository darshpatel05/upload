#include <stdio.h>

int add(int a, int b);          // add function takes two parameters of type int and adds the two parameters together
int subtract(int a, int b);     // subtract function takes two parameters of type int and finds the difference between the two parameters
int multiply(int a, int b);     // multiply function takes two parameters of type int and finds the product of the two parameters
float divide(int a, int b);     // division function takes two parameters of type int and divides the first parameter by the second parameter

int main(void) {
    int num1 = 0, num2 = 0, buffer;

    // User inputs with buffer to prevent invalid inputs
    do {
        printf("Enter the first number: ");
        buffer = scanf("%d", &num1);
        if (buffer != 1) {
            printf("Invalid Input!\n");
            while (getchar() != '\n');
        }
    } while(buffer != 1);

    do {
        printf("Enter the second number: ");
        buffer = scanf("%d", &num2);
        if (buffer != 1) {
            printf("Invalid Input!\n");
            while (getchar() != '\n');
        }
    } while(buffer != 1);

    // Formatted Output
    printf("\nResults:\n");
    printf("%d + %d = %d\n", num1, num2, add(num1, num2));
    printf("%d - %d = %d\n", num1, num2, subtract(num1, num2));
    printf("%d * %d = %d\n", num1, num2, multiply(num1, num2));
    // If statement to handle division by 0
    if (num2 == 0) {
        divide(num1, num2);
    } else {
        printf("%d / %d = %.3f\n", num1, num2, divide(num1, num2));
    }

    return 0;
}

int add(int a, int b)  {
    /*
    The function takes in parameters a and b of type int, adds the two parameters together, and returns the sum as type int.
    */
    int sum = a + b;
    return sum;
}

int subtract(int a, int b) {
    /*
    The function takes in parameters a and b of type int, subtracts the parameter b from a, and returns the difference as type int.
    */
    int difference = a - b;
    return difference;
}

int multiply(int a, int b) {
    /*
    The function takes in parameters a and b of type int, multiplies the two parameters together, and returns the product as type int.
    */
    int product = a * b;
    return product;
}

float divide(int a, int b) {
    /*
    The function takes in parameters a and b of type int, divides the parameter b from a, and returns the quotient as type float.
    */
    // If statement for division by 0
    if (b == 0) {
        printf("%d / %d = [ERROR: RESULT IS UNDEFINED]\n", a, b);
    }
    float quotient = (float) a / b;
    return quotient;
}