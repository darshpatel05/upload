#include <stdio.h>
#include "grade_functions.h"

int main() {
    float grade;

    // Test case for calculate average function
    printf("Test Case 1:\n");
    grade = calculateAverage(12.3, 100, 0);
    printGradeReport(grade, determineLetterGrade(grade));

    // Test case for boundary conditions
    printf("\nTest Case 2:\n");
    grade = 100;
    printGradeReport(grade, determineLetterGrade(grade));

    // Test case for boundary conditions
    printf("\nTest Case 3:\n");
    grade = 59;
    printGradeReport(grade, determineLetterGrade(grade));

    // Test case for invalid input of the char parameter for the printGradeReport function
    printf("\nTest Case 4:\n");
    grade = 100;
    printGradeReport(grade, 'K');

    // Test case for invalid input of the grade parameter for the printGradeReport function
    printf("\nTest Case 5:\n");
    grade = -98;
    printGradeReport(grade, determineLetterGrade(grade));
}