#ifndef GRADE_FUNCTIONS_H
#define GRADE_FUNCTIONS_H

float calculateAverage(float grade1, float grade2, float grade3);
char determineLetterGrade(float grade);
void printGradeReport(float grade, char letterGrade);

#endif
