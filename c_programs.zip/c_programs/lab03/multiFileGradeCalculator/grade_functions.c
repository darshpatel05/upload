#include <stdio.h>
#include "grade_functions.h"

float calculateAverage(float grade1, float grade2, float grade3) {
    /*
    Function takes three individual grades of type float as parameters and returns the average of the three grades as a type float
    */
    float average = (grade1 + grade2 + grade3) / 3;
    return average;
}
char determineLetterGrade(float grade) {
    /*
    Function takes a parameter of type float representing a grade value, and uses if statements to correlate the numeric grade to a letter grade
    */
    if (grade <= 100 && grade >= 90) {
        return 'A';
    } else if (grade < 90 && grade >= 80) {
        return 'B';
    } else if (grade < 80 && grade >= 70) {
        return 'C';
    } else if (grade < 70 && grade >= 60) {
        return 'D';
    } else if (grade < 60 && grade >= 0) {
        return 'F';
    } else {
        printf("ERROR: Input grade is out of range.\n");
        return '0';
    }
}
void printGradeReport(float grade, char letterGrade) {
    /*
    Function takes a numeric grade parameter of type float and letter grade parameter of type char and formats them to print
    */
    // Checks for validity of grade parameter input
    if (grade <= 100 && grade >= 0) {
        printf("Numeric Grade: %.1f\n", grade);
    } else {
        printf("Invalid numeric grade!\n");
    }

    // Checks for validity of letterGrade parameter input
    if (letterGrade == 'A' || letterGrade == 'B' || letterGrade == 'C' || letterGrade == 'D' || letterGrade == 'F') {
        printf("Letter Grade: %c\n", letterGrade);
    } else {
        printf("Invalid letter grade!\n");
    }
}