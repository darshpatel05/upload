#include <array>
#include <iostream>

template <typename T, size_t Rows, size_t Cols>
class Matrix {
public:
    Matrix() {
        for(size_t i = 0; i < Rows; i++) {
            for(size_t j = 0; j < Cols; j++) {
                data_[i][j] = T{};
            }
        }
    }

    Matrix(const std::array<std::array<T, Cols>, Rows>& data) {
        data_ = data;
    }

    T& at(size_t i, size_t j) {
        return data_[i][j];
    }

    const T& at(size_t i, size_t j) const {
        return data_[i][j];
    }

    Matrix operator+(const Matrix& rhs) const {
        Matrix result;
        for(int i = 0; i < Rows; i++) {
            for(size_t j = 0; j < Cols; j++) {
                result.data_[i][j] = data_[i][j] + rhs.data_[i][j];
            }
        }
        return result;
    }

    Matrix operator*(const Matrix& rhs) const {
        Matrix result;
        for (size_t i = 0; i < Rows; ++i) {
            for (size_t j = 0; j < Cols; ++j) {
                result.data_[i][j] = T{};
                for (size_t k = 0; k < Cols; ++k) {
                    result.data_[i][j] += data_[i][k] * rhs.data_[k][j];
                }
            }
        }
        return result;
    }

    std::array<T, Cols>& operator[](size_t i) {
        if (i >= Rows) {
            throw std::out_of_range("Matrix row index out of bounds");
        }
        return data_[i];
    }

    friend std::ostream& operator<<(std::ostream& os, const Matrix& rhs) {
        for(size_t i = 0; i < Rows; ++i) {
            for(size_t j = 0; j < Cols; ++j) {
                os << rhs.data_[i][j] << " ";
            }
            os << "\n";
        }
        return os;
    }

    T determinant() {
        return data_[0][0] * data_[1][1] -  data_[0][1] * data_[1][0];
    }

    Matrix inverse() {
        Matrix result;
        result.data_ = data_;

        T det = result.determinant();

        T temp = result.data_[0][0];
        result.data_[0][0] = result.data_[1][1];
        result.data_[1][1] = temp;
        
        result.data_[0][1] *= -1;
        result.data_[1][0] *= -1;

        result.data_[0][0] /= det;
        result.data_[0][1] /= det;
        result.data_[1][0] /= det;
        result.data_[1][1] /= det;

        return result;
    }

    std::array<T, 2> solve(std::array<T, 2>& c) {

        T det = determinant();

        Matrix x;
        x.data_ = data_;
        x.data_[0][0] = c[0];
        x.data_[1][0] = c[1];
        T x_det = x.determinant();

        Matrix y;
        y.data_ = data_;
        y.data_[0][1] = c[0];
        y.data_[1][1] = c[1];
        T y_det = y.determinant();

        std::array<T, 2> result {x_det / det, y_det / det};
        return result;
    }
    
protected:
    std::array<std::array <T, Cols>, Rows> data_;
};
