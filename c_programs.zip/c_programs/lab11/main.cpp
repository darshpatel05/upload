#include <iostream>
#include "matrix.cpp"

int main() {
    // Create 2x2 matrices
    Matrix<double, 2, 2> m1 {{
        std::array<double, 2>{1.0, 2.0},
        std::array<double, 2>{3.0, 4.0}
    }};
    
    Matrix<double, 2, 2> m2 {{
        std::array<double, 2>{2.0, 0.0},
        std::array<double, 2>{1.0, 3.0}
    }};

    // Test operations
    std::cout << "m1:\n" << m1 << std::endl;
    std::cout << "m2:\n" << m2 << std::endl;
    std::cout << "m1 + m2:\n" << (m1 + m2) << std::endl;
    std::cout << "m1 * m2:\n" << (m1 * m2) << std::endl;

    // For 2x2 specialization
    std::cout << "det(m1) = " << m1.determinant() << std::endl;
    auto m1_inv = m1.inverse();
    std::cout << "inv(m1):\n" << m1_inv << std::endl;

    // // Test system solving
    std::array <double, 2> b = {5.0, 11.0};
    auto x = m1.solve(b);
    std::cout << "Solution: x = " << x[0]
              << ", y = " << x[1] << std::endl;

    return 0;
}

