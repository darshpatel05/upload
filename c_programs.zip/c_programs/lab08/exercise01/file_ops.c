// file_ops.c
#include "file_ops.h"
#include <ctype.h>  //rec

FILE* safe_fopen(const char* filename, const char* mode) {

    FILE* fp = fopen(filename, mode);

    if(fp == NULL) {
        fprintf(stderr, "Error opening file %s: %s\n", filename, strerror(errno));
    }

    return fp;
}

// Starter implementation of safe_fclose
int safe_fclose(FILE** fp) {
    if (fp == NULL || *fp == NULL) {
        return -1;
    }
    
    int result = fclose(*fp);
    if (result == 0) {
        *fp = NULL;
    }
    return result;
}

int count_words(const char* filename) {

    FILE* fp = safe_fopen(filename, "r");

    if (fp == NULL) {
        return -1;
    }

    int num_words = 0;
    int word = 0;
    int c;

    while((c = fgetc(fp)) != EOF) {
        if(isspace(c)) {
            word = 0;
        } else if(!word) {
            word = 1;
            num_words++;
        }
    }

    return num_words;
}