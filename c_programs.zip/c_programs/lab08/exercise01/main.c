#include <stdio.h>
#include "file_ops.h"

int test_safe_fopen();
int test_basic_ops();
int test_word_count();



int main() {
    test_safe_fopen();
    test_basic_ops();
    test_word_count();
}

int test_safe_fopen() {
    // Test opening existing file
    FILE* fp = safe_fopen("test.txt", "r");
    if (fp == NULL) {
        printf("Failed to open non-existent file (expected)\n");
    }

    // Test creating new file
    fp = safe_fopen("test.txt", "w");
    if (fp != NULL) {
        printf("Successfullly created new file\n");
        safe_fclose(&fp);
    }

    return 0;
}

int test_basic_ops() {
    // Write to file
    FILE* fp = safe_fopen("test.txt", "w");
    if (fp != NULL) {
        fprintf(fp, "Hello, World!\n");
        safe_fclose(&fp);
    }

    // Read from file
    char buffer[100];
    fp = safe_fopen("test.txt", "r");
    if (fp != NULL) {
        if (fgets(buffer, sizeof(buffer), fp) != NULL) {
            printf("Read from file: %s", buffer);
        }
    }

    return 0;
}

int test_word_count() {
    // Create test file
    FILE* fp = safe_fopen("test.txt", "w");
    if (fp != NULL) {
        fprintf(fp, "This is a test file.\n");
        fprintf(fp, "It has multiple words on multiple lines.\n");
        safe_fclose(&fp);
    }

    // Count words
    int words = count_words("test.txt");
    printf("Word count: %d\n", words);

    return 0;
}