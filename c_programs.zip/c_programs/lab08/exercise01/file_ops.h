// file_ops.h
#ifndef FILE_OPS_H
#define FILE_OPS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// Safely open a file with error reporting
// Returns a file pointer if successful, NULL otherwise
FILE* safe_fopen(const char* filename, const char* mode);

// Safely close a file and set the pointer to NULL
// Returns 0 on success, -1 on error
int safe_fclose(FILE** fp);

// Count words in a file (like 'wc -w' command)
// Returns the number of words, or -1 on error
int count_words(const char* filename);

#endif // FILE_OPS_H