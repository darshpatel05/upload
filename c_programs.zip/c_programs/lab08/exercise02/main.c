#include <stdio.h>
#include "csv_parser.h"

int main() {
    // Create a sample CSV file for testing
    FILE *fp = fopen("students.csv", "w");
    if (fp == NULL) {
        perror("Error creating test file");
        return 1;
    }

    fprintf(fp, "id,name,age,score\n");
    fprintf(fp, "1,\"Smith, John\",25,95.5\n");
    fprintf(fp, "2,Jane Doe,22,88.0\n");
    fprintf(fp, "3,\"Williams, Robert\",28,76.5\n");
    fprintf(fp, "4,\"Johnson, Emily\",21,92.0\n");
    fprintf(fp, "5,Michael Brown,24,65.5\n");
    fclose(fp);

    // Read and parse the CSV file
    CSVData *data = read_csv_file("students.csv", 1);

    if (data == NULL) {
        printf("Failed to read CSV file\n");
        return 1;
    }

    // Extract and display the name column
    // int count;
    // char **names = extract_column(data, 1, &count);
    // if (names != NULL) {
    //     printf("\nStudent names:\n");
    //     for (int i = 0; i < count; i++) {
    //         printf("%s\n", names[i]);
    //     }

    //     // Free the extracted column
    //     for (int i = 0; i < count; i++) {
    //         free(names[i]);
    //     }
    //     free(names);
    // }

    // Compute statistics on the score column
    // double min, max, avg;
    // if (compute_column_stats(data, 3, &min, &max, &avg) == 0) {
    //     printf("\nScore statistics:\n");
    //     printf("Min: %.1f\n", min);
    //     printf("Max: %.1f\n", max);
    //     printf("Average: %.1f\n", avg);
    // }

    // Clean up
    free_csv_data(data);
    return 0;
}

//-----------------------------------------------------------------

// int test_simple_csv_parsing();
// int test_quoted_fields();
// int test_column_stats();



// int main() {
//     test_simple_csv_parsing();
//     // test_quoted_fields();
//     // test_column_stats();
// }

// int test_simple_csv_parsing() {
//     const char *test_line = "1, Jane, 25, 95.5";
//     CSVRow row = parse_csv_line(test_line);

//     printf("Field count: %d\n", row.field_count);
//     for (int i = 0; i < row.field_count; i++) {
//         printf("Field %d: %s\n", i, row.fields[i]);
//     }

//     free_csv_row(&row);
//     return 0;
// }

// // int test_quoted_fields() {
// //     const char *test_line = "1, \"Smith, John\", 25, 95.5";
// //     CSVRow row = parse_csv_line(test_line);

// //     printf("Field count: %d\n", row.field_count);
// //     for (int i = 0; i < row.field_count; i++) {
// //         printf("Field %d: %s\n", i, row.fields[i]);
// //     }

// //     free_csv_row(&row);
// //     return 0;
// // }

// // int test_column_stats() {
// //     // Create test CSV data
// //     CSVData *data = malloc(sizeof(CSVData));
// //     data->row_count = 3;
// //     data->rows = malloc(3 * sizeof(CSVRow));

// //     // Create test rows
// //     data->rows[0] = parse_csv_line("id,name,age,score");
// //     data->rows[1] = parse_csv_line("1,Jane,25,95.5");
// //     data->rows[2] = parse_csv_line("2,John,30,88.0");

// //     // Calculate statistics for score column
// //     double min, max, avg;
// //     if (compute_column_stats(data, 3, &min, &max, &avg) == 0) {
// //         printf("Score statistics:\n");
// //         printf("Min: %.1f\n", min);
// //         printf("Max: %.1f\n", max);
// //         printf("Average: %.1f\n", avg);
// //     }

// //     free_csv_data(data);
// //     return 0;
// //}
