// csv_parser.c
#include "csv_parser.h"

// Parse a CSV line into an array of strings
CSVRow parse_csv_line(const char *line) {
    
    CSVRow row;
    row.fields = NULL;
    row.field_count = 0;
    
    if(line == NULL) {
        return row;
    }

    for(int i = 0; i < strlen(line); i++) {
        if(line[i] == ',') {
            row.field_count++;
        }
    }
    row.field_count++;

    row.fields = (char**)malloc(row.field_count * sizeof(char*));
    if(row.fields == NULL) {
        printf("Memory allocation of CSV row fields failed!\n");
        row.field_count = 0;
        return row;
    }

    int index = 0;
    int field_index = 0;
    int start_index = 0;
    for(int i = 0; i < row.field_count; i++) {
        while(line[index] != ',' && line[index] != '\0') {
            index++;
        }

        row.fields[field_index] = (char*)malloc((index - start_index + 1) * sizeof(char));
        if(row.fields[field_index] == NULL) {
            printf("Memory allocation of field element failed!\n");
            for (int i = 0; i < field_index; i++) {
                free(row.fields[i]);
            }
            return row;
        }
        
        strncpy(row.fields[field_index], line + start_index, index - start_index);
        row.fields[field_index][index - start_index] = '\0';


        field_index++;
        start_index = index + 2;
        index++;
    }

    return row;

}

// Free memory allocated for a CSVRow
void free_csv_row(CSVRow *row) {
    if (row == NULL || row->fields == NULL) return;

    for (int i = 0; i < row->field_count; i++) {
        free(row->fields[i]);
    }
    free(row->fields);
    row->fields = NULL;
    row->field_count = 0;
}

// Read a CSV file and parse it into a CSVData structure
CSVData *read_csv_file(const char *filename, int header_row) {
    
    CSVData* data = (CSVData*)malloc(sizeof(CSVData));
    if(data == NULL) {
        printf("Memory allocation of CSVData failed!\n");
        return NULL;
    }
    data->rows = NULL;
    data->row_count = 0;
    data->header_row = header_row;


    FILE* fp = fopen(filename, "r");

    if(fp == NULL) {
        fprintf(stderr, "Error opening file %s: %s\n", filename, strerror(errno));
    }

    int c;
    int index = 0;
    char* str;

    while((c = fgetc(fp)) != EOF) {
        if(c == '\n') {
            data->row_count++;
            str = (char*)malloc((index + 1) * sizeof(char));
            if(str == NULL) {
                printf("Memory allocation for line failed!\n");
                fclose(fp);
                return NULL;
            }
            str = fgets(str, index, fp);
            data->rows[data->row_count] = parse_csv_line(str);
        } else {
            index++;
        }
    }
    
    return data;
}

// Free memory allocated for a CSVData structure
void free_csv_data(CSVData *data) {
    if (data == NULL) return;

    for (int i = 0; i < data->row_count; i++) {
        free_csv_row(&data->rows[i]);
    }

    free(data->rows);
    free(data);
}

// Extract a specific column from CSVData as an array of strings
char **extract_column(CSVData *data, int column_index, int *count) {
    if (data == NULL) {
        return;
    }

    char** arr = (char**)malloc(sizeof(char*));

    for(int i = 0; i < data->rows->field_count; i++) {
        for(int j = 0; j < data->row_count; j++) {
            
        }
    }
}

// Extract a specific column from CSVData as an array of doubles
double *extract_numeric_column(CSVData *data, int column_index, int *count);

// Compute statistics on a numeric column
int compute_column_stats(CSVData *data, int column_index, double *min, double *max, double *avg);
