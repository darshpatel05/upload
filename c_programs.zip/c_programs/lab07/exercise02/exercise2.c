#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Dynamic array structure
typedef struct {
    int *data;       // Pointer to the data array
    int size;        // Current number of elements
    int capacity;    // Maximum capacity
} DynamicArray;

// Function Signatures
DynamicArray* createArray(int initialCapacity);
void destroyArray(DynamicArray* arr);
int resizeArray(DynamicArray* arr, int newCapacity);
int pushBack(DynamicArray* arr, int value);
int getAt(DynamicArray* arr, int index);
int setAt(DynamicArray* arr, int index, int value);
int insertAt(DynamicArray* arr, int index, int value);
int removeAt(DynamicArray* arr, int index);
int find(DynamicArray* arr, int value);
void clear(DynamicArray* arr);
int isEmpty(DynamicArray* arr);
int size(DynamicArray* arr);
int capacity(DynamicArray* arr);
void printArray(DynamicArray* arr);

int main() {
    DynamicArray* arr = createArray(8);
    pushBack(arr, 10);
    pushBack(arr, 20);
    pushBack(arr, 30);
    pushBack(arr, 40);
    pushBack(arr, 50);
    pushBack(arr, 60);
    pushBack(arr, 70);
    pushBack(arr, 80);
    pushBack(arr, 90);
    pushBack(arr, 100);
    printArray(arr);
    
    // printf("set 3 to 47 was a %d\n", setAt(arr, 3, 47));
    // printArray(arr);
    // printf("At idex 7, we have element %d\n", getAt(arr, 7));
    // printf("inserting element at index 6 was a %d\n",insertAt(arr, 6, 66));
    // printArray(arr);
    // printf("removing element at index 2 was a %d\n",removeAt(arr, 6));
    // printArray(arr);
    printf("Resized array 10:\n");
    resizeArray(arr, 10);
    pushBack(arr, 110);
    pushBack(arr, 120);
    pushBack(arr, 130);
    printArray(arr);
    printf("Resized array 8:\n");
    resizeArray(arr, 8);
    printArray(arr);
    printf("size of array is %d\n", size(arr));
    clear(arr);
    printf("is empty? %d\n", isEmpty(arr));
    printf("found 47 at %d\n", find(arr, 47));

    destroyArray(arr);
    
    return 0;
}

// Initialize a dynamic array with a specified initial capacity
// Returns a pointer to the array, or NULL if allocation fails
DynamicArray* createArray(int initialCapacity) {
    DynamicArray* arr = (DynamicArray*)malloc(sizeof(DynamicArray));
    
    if (arr == NULL) {
        printf("Dynamic Attay Intialization : Memory Allocation Failure\n");
        return NULL;
    }
    
    arr->data = (int*)malloc(initialCapacity * sizeof(int));
    
    if (arr->data == NULL) {
        printf("Data Intialization : Memory Allocation Failure\n");
        free(arr);
        return NULL;
    }
    
    arr->capacity = initialCapacity;
    arr->size = 0;
    
    return arr;
}

// Free all memory allocated for the dynamic array
void destroyArray(DynamicArray* arr) {
    //free array data then array
    if(arr != NULL) {
        if(arr->data != NULL) {
            free(arr->data);
        }
        free(arr);
    }
}

// Resize the array to a new capacity
// Returns 1 if successful, 0 if allocation fails
int resizeArray(DynamicArray* arr, int newCapacity) {
    // reallocates the current memory to fit the new capacity and adjust the current size of data accordingly
    arr->data = (int*)realloc(arr->data, newCapacity * sizeof(int));
    if (arr->data == NULL) {
        printf("Resizing array to larger capacity : Memory Allocation Failure\n");
        return 0;
    }
    arr->capacity = newCapacity;
    if(arr->size > arr->capacity) {
        arr->size = arr->capacity;
    }
    return 1;
}

// Add an element to the end of the array
// Returns 1 if successful, 0 if allocation fails
int pushBack(DynamicArray* arr, int value) {
    if(arr->size >= arr->capacity) {
        printf("Dynamic Array is currently at maximum capacity.\n");
        return 0;
    }

    // reallocates memory if array needs increased capacity
    if(size == capacity) {
        arr->data = (int*)realloc(arr->data, (arr->size + 1) * sizeof(int));
        if (arr->data == NULL) {
            printf("Pushing back data in array : Memory Allocation Failure\n");
            return 0;
        }
        arr->capacity++;
    }

    arr->data[arr->size] = value;

    arr->size++;

    return 1;
}

// Get the element at the specified index
// Returns the element, or -1 if the index is out of bounds
int getAt(DynamicArray* arr, int index) {
    if(arr->size <= index || index < 0) {
        return -1;
    }
    return arr->data[index];
}

// Set the element at the specified index
// Returns 1 if successful, 0 if the index is out of bounds
int setAt(DynamicArray* arr, int index, int value) {
    if(arr->size <= index || index < 0) {
        return 0;
    }
    arr->data[index] = value;
    return 1;
}

// Insert an element at the specified index
// Returns 1 if successful, 0 if the index is out of bounds or allocation fails
int insertAt(DynamicArray* arr, int index, int value) {
    if(arr->size <= index || index < 0) {
        return 0;
    }
    // Starts by pushing the last element by one and then traverses the array backwards push the rest back until the given index, upon which the given value is inserted
    pushBack(arr, arr->data[arr->size - 1]);

    for(int i = arr->size - 1; i > index; i--) {
        arr->data[i] = arr->data[i - 1];
    }

    arr->data[index] = value;

    return 1;
}

// Remove the element at the specified index
// Returns 1 if successful, 0 if the index is out of bounds
int removeAt(DynamicArray* arr, int index) {
    if(arr->size <= index || index < 0) {
        return 0;
    }
    // removes the specified index by shifting all elements over by one from the given index
    for(int i = index; i < arr->size - 1; i++) {
        arr->data[i] = arr->data[i + 1];
    }

    arr->size--;

    return 1;
}

// Find the first occurrence of a value
// Returns the index of the element, or -1 if not found
int find(DynamicArray* arr, int value) {
    for(int i = 0; i < arr->size; i++) {
        if(arr->data[i] == value) {
            return i;
        }
    }
    return -1;
}

// Remove all elements from the array
void clear(DynamicArray* arr) {
    for(int i = 0; i < arr->capacity; i++) {
        arr->data[i] = 0;
    }
    arr->size = 0;
}

// Check if the array is empty
// Returns 1 if empty, 0 otherwise
int isEmpty(DynamicArray* arr) {
    return arr->size == 0;
}

// Get the current size of the array
int size(DynamicArray* arr) {
    return arr->size;
}

// Get the current capacity of the array
int capacity(DynamicArray* arr) {
    return arr->capacity;
}

// Print the array contents
void printArray(DynamicArray* arr) {
    for(int i = 0; i < arr->size; i ++) {
        printf("%d ", arr->data[i]);
    }
    printf("\n");
}