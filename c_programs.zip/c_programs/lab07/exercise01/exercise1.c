//chatGPT logs: https://chatgpt.com/share/67d51782-8308-8013-bbb7-15960961fcd5
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Student record structure
typedef struct {
    int id;
    char name[50];
    char major[50];
    float gpa;
} Student;

// Student database structure
typedef struct {
    Student *students; // Dynamic array of students
    int capacity; // Maximum capacity
    int count; // Current number of students
} StudentDB;

// Function Signatures
StudentDB *initializeDB(int capacity);
int addStudent(StudentDB *db, int id, const char *name, const char *major, float gpa);
Student *findStudentByID(StudentDB *db, int id);
int removeStudent(StudentDB *db, int id);
void freeStudentDB(StudentDB *db);
Student **findStudentsByGPA(StudentDB *db, float min_gpa, int *count_out);
Student **findStudentsByMajor(StudentDB *db, const char *major, int *count_out);
void sortStudentsByGPA(StudentDB *db);
void printAllStudents(StudentDB *db);

int main() {
    StudentDB* db;
    db = initializeDB(4);
    addStudent(db, 1019, "John Doe", "Engineering", 3.91);
    addStudent(db, 1020, "Mac Reddy", "Biology", 2.11);
    addStudent(db, 1021, "Bailey Filtorpe", "Literature", 3.17);
    addStudent(db, 1022, "Jimmy Butler", "Exercise Science", 3.99);

    printAllStudents(db);
    sortStudentsByGPA(db);
    printf("-------------------\n");
    printAllStudents(db);
    int count;
    Student** smth = findStudentsByMajor(db, "Engineering", &count);

    for(int i = 0; i < count; i++) {
        printf("ID: %d\n", smth[i]->id);
        printf("Name: \"%s\"\n", smth[i]->name);
        printf("Major: \"%s\"\n", smth[i]->major);
        printf("GPA: %.2f\n", smth[i]->gpa);
        printf("\n");
    }
    
    free(smth);
    freeStudentDB(db);
    
    return 0;
}

// Initialize a student database with a specified capacity
// Returns a pointer to the database, or NULL if allocation fails
StudentDB *initializeDB(int capacity) {
    StudentDB* db = (StudentDB*)malloc(sizeof(StudentDB));
    
    if (db == NULL) {
        printf("Student Database Intialization : Memory Allocation Failure\n");
        return NULL;
    }
    
    db->students = (Student*)malloc(capacity * sizeof(Student));
    
    if (db->students == NULL) {
        printf("Student Array Intialization : Memory Allocation Failure\n");
        free(db);
        return NULL;
    }
    
    db->capacity = capacity;
    db->count = 0;
    
    return db;
}

// Add a student to the database
// Returns 1 if successful, 0 if the database is full or on error
int addStudent(StudentDB *db, int id, const char *name, const char *major, float gpa) {
    if(db->count >= db->capacity) {
        printf("Database is currently at maximum capacity.\n");
        return 0;
    }
    // Reallocates memory to create additional space for the student
    db->students = (Student*)realloc(db->students, (db->count + 1) * sizeof(Student));
    
    if (db->students == NULL) {
        printf("Adding Student to Database : Memory Allocation Failure\n");
        return 0;
    }

    // Adds the attributes to the new student in the database
    db->students[db->count].id = id;
    
    strncpy(db->students[db->count].name, name, 49);
    db->students[db->count].name[49] = '\0';
    
    strncpy(db->students[db->count].major, major, 49);
    db->students[db->count].major[49] = '\0';
    
    db->students[db->count].gpa = gpa;
    
    db->count++;

    return 1;
}

// Search for a student by ID
// Returns a pointer to the student if found, NULL otherwise
Student *findStudentByID(StudentDB *db, int id) {
    // Traverses through database to find the student with the given id
    for(int i = 0; i < db->count; i++) {
        if(db->students[i].id == id) {
            return &db->students[i];
        }
    }

    printf("Student with the id \"%d\" could not be found.\n", id);
    return NULL;
}

// Remove a student from the database by ID
// Returns 1 if successful, 0 if the student was not found
int removeStudent(StudentDB *db, int id) {
    // TO remove the student, traverse throught the database from the very end to the position of the student being removed and shift every student over one in the database
    for(int i = 0; i < db->count; i++) {
        if(db->students[i].id == id) {
            for(int j = i; j < db->count - 1; j++) {
                db->students[j] = db->students[j + 1];
            }
            db->count--;
            return 1;
        }
    }

    return 0;
}

// Free all memory allocated for the database
void freeStudentDB(StudentDB *db) {
    free(db->students);
    free(db);
}

// Find students with a GPA above a specified threshold
// Returns a new array of pointers to matching students and sets count_out to the number of matches
Student **findStudentsByGPA(StudentDB *db, float min_gpa, int *count_out) {
    //determine the number of matches
    *count_out = 0;
    for(int i = 0; i < db->count; i++) {
        if(db->students[i].gpa >= min_gpa) {
            (*count_out)++;
        }
    }
    // allocate the memory based on the number of matches
    Student** dbGPA = malloc(*count_out * sizeof(Student*));

    if (dbGPA == NULL) {
        rintf("Memory allocation failed for array of students with matching GPAs\n");
        return NULL;
    }
    // extract the information about the students that meet the requirements into the new array
    int count = 0;
    for(int i = 0; i < db->count; i++) {
        if(db->students[i].gpa >= min_gpa) {
            dbGPA[count++] = &db->students[i];
        }
    }

    return dbGPA;
}

// Find students in a specific major
// Returns a new array of pointers to matching students and sets count_out to the number of matches
Student **findStudentsByMajor(StudentDB *db, const char *major, int *count_out) {
    // determine number of matches
    *count_out = 0;
    for(int i = 0; i < db->count; i++) {
        if(strcmp(db->students[i].major, major) == 0) {
            (*count_out)++;
        }
    }

    // allocate memory based on number of matches
    Student** dbMajor = malloc(*count_out * sizeof(Student*));

    if (dbMajor == NULL) {
        printf("Memory allocation failed for array of students with matching majors\n");
        return NULL;
    }

    // extract student information into new array based on met requirements
    int count = 0;
    for(int i = 0; i < db->count; i++) {
        if(strcmp(db->students[i].major, major) == 0) {
            dbMajor[count++] = &db->students[i];
        }
    }

    return dbMajor;
}

// Sort students by GPA (descending order)
void sortStudentsByGPA(StudentDB *db) {
    if(db == NULL) {
        return;
    }

    Student temp = db->students[0];

    //sorting algorithm in descending order
    for(int i = 0; i < db->count; i++) {
        for(int j = i; j < db->count; j++) {
            if(db->students[j].gpa >= db->students[i].gpa) {
                temp = db->students[i];
                db->students[i] = db->students[j];
                db->students[j] = temp;
            }
        }
    }
}

// Print all student records in a formatted way
void printAllStudents(StudentDB *db) {
    if(db == NULL) {
        return;
    }

    for(int i = 0; i < db->count; i++) {
        printf("ID: %d\n", db->students[i].id);
        printf("Name: \"%s\"\n", db->students[i].name);
        printf("Major: \"%s\"\n", db->students[i].major);
        printf("GPA: %.2f\n", db->students[i].gpa);
        printf("\n");
    }
}