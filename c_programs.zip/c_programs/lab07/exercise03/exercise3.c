#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Node structure
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Linked list structure
typedef struct {
    Node* head;
    int size;
} LinkedList;

// Function Signature
LinkedList* createList();
void destroyList(LinkedList* list);
int addFirst(LinkedList* list, int value);
int addLast(LinkedList* list, int value);
int insertAt(LinkedList* list, int position, int value);
int removeAt(LinkedList* list, int position);
int find(LinkedList* list, int value);
int getAt(LinkedList* list, int position);
int isEmpty(LinkedList* list);
int size(LinkedList* list);
void clear(LinkedList* list);
void printList(LinkedList* list);

int main() {
    LinkedList* list = createList();
    addFirst(list, 10);
    addLast(list, 20);
    addLast(list, 30);
    addLast(list, 40);
    printList(list);
    printf("find 40 at position %d\n", find(list, 40));
    printf("inserting was %d\n", insertAt(list, 2, 12));
    printList(list);
    printf("removal was %d\n", removeAt(list, 2));
    printList(list);
    printf("is the list empty? %d\n", isEmpty(list));
    destroyList(list);
    return 0;
}

// Initialize a linked list
// Returns a pointer to the list, or NULL if allocation fails
LinkedList* createList() {
    LinkedList* list = (LinkedList*)malloc(sizeof(LinkedList));
    
    if (list == NULL) {
        printf("Linked List Intialization : Memory Allocation Failure\n");
        return NULL;
    }

    list->size = 0;
    
    return list;
}

// Free all memory allocated for the linked list
void destroyList(LinkedList* list) {
    //clears each node before clearing list
    clear(list);

    if(list != NULL) {
        free(list);
    }
}

// Add an element to the beginning of the list
// Returns 1 if successful, 0 if allocation fails
int addFirst(LinkedList* list, int value) {
    // New node to place as the head
    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        printf("Memory Allocation Failure\n");
        return 0;
    }

    // Create new node that holds the given value and has the head of the list as its next node
    new_node->data = value;
    new_node->next = list->head;

    // Sets the head of list as the new node
    list->head = new_node;

    list->size++;

    return 1;
}

// Add an element to the end of the list
// Returns 1 if successful, 0 if allocation fails
int addLast(LinkedList* list, int value) {
    // New node with given value to place as the tail
    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        printf("Memory Allocation Failure\n");
        return 0;
    }
    new_node->data = value;

    // If list is empty the new node is placed as the head
    if(list->head == NULL) {
        list->head = new_node;
        list->size++;
        return 1;
    }

    // Create new node that holds the given value and has the head of the list as its next node
    Node* current = list->head;
    // Starting from the head the next node after current is constantly checked to see the next node until the tail is reached and has its next node be the new node
    while(current->next != NULL) {
        current = current->next;
    }
    current->next = new_node;
    list->size++;

    return 1;
}

// Insert an element at the specified position
// Returns 1 if successful, 0 if the position is invalid or allocation fails
int insertAt(LinkedList* list, int position, int value) {
    if(position < 0 || position > size(list)) {
        return 0;
    }

    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        printf("Memory Allocation Failure\n");
        return 0;
    }
    new_node->data = value;

    Node* current = list->head;
    int count = 0;
    // Starting from the head the node current is constantly changed to the next node and the data of it is compared to the given value
    while(current != NULL && count < position - 1) {
        current = current->next;
        count++;
    }
    
    new_node->next = current->next;
    current->next = new_node;

    list->size++;
    
    return 1;
}

// Remove the element at the specified position
// Returns 1 if successful, 0 if the position is invalid
int removeAt(LinkedList* list, int position) {
    if(position < 0 || position > size(list)) {
        return 0;
    }
    //Finds the nodes before and after the given position and makes the next value of the previous node the node in the following position
    Node* current = list->head;
    Node* next1 = current->next;
    Node* next2 = next1->next;
    int count = 0;
    while(current->next != NULL && count < position - 1) {
        current = current->next;
        next1 = current->next;
        next2 = next1->next;
        count++;
    }
    current->next = next2;
    return 1;
}

// Find the first occurrence of a value
// Returns the position of the element, or -1 if not found
int find(LinkedList* list, int value) {
    Node* current = list->head;
    int count = 0;
    // Starting from the head the node current is constantly changed to the next node and the data of it is compared to the given value
    while(current != NULL) {
        if(current->data == value) {
            return count;
        }
        current = current->next;
        count++;
    }
    return -1;
}

// Get the element at the specified position
// Returns the element, or -1 if the position is invalid
int getAt(LinkedList* list, int position) {
    if (position < 0 || position >= list->size) {
        return -1;
    }
    
    Node* current = list->head;
    int count = 0;
    // Starting from the head the node current is constantly changed to the next node and the data of it is compared to the given value
    while(current != NULL && count <= position) {
        if(count == position) {
            return current->data;
        }
        current = current->next;
        count++;
    }
    return -1;
}

// Check if the list is empty
// Returns 1 if empty, 0 otherwise
int isEmpty(LinkedList* list) {
    // Checks if there is a head to the linked list, since other wise the list would be non-existent
    return list->head == NULL;
}

// Get the current size of the list
int size(LinkedList* list) {
    int count = 0;

    Node* current = list->head;

    while(current != NULL) {
        current = current->next;
        count++;
    }

    return count;
}

// Remove all elements from the list
void clear(LinkedList* list) {
    Node* current = list->head;
    Node* next;

    while(current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    list->size = 0;
}

// Print the list contents
void printList(LinkedList* list) {
    Node* current = list->head;

    // Starting from the head the node current is constantly changed to the next node and the data of it is printed
    while(current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}