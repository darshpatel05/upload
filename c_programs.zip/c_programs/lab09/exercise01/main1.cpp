#include <iostream>
#include "student.h"

int test_class_definition() {
    // Create a student object
    Student s1("John Doe", 12345, 3.7);

    // Try to access private members (should cause compilation error)
    // Uncomment to test:
    // std::cout << s1.name << std::endl; // Error: private member

    // Use public methods to access information
    std::cout << "Student ID: " << s1.getID() << std::endl;
    std::cout << "Student Name: " << s1.getName() << std::endl;
    std::cout << "Student GPA: " << s1.getGPA() << std::endl;

    return 0;
}

int test_constructors() {
    // Test default constructor
    Student s1;
    std::cout << "Default student: " << s1.getName() << ", ID: " << s1.getID() << ", GPA: " << s1.getGPA() << std::endl;

    // Test parameterized constructor
    Student s2("Jane Smith", 67890, 3.9);
    std::cout << "Student 2: " << s2.getName() << ", ID: " << s2.getID() << ", GPA: " << s2.getGPA() << std::endl;

    return 0;
}

int test_methods() {
    // Create student and test setter methods
    Student s1;
    s1.setName("Alice Johnson");
    s1.setID(54321);
    s1.setGPA(3.5);

    // Display student information
    std::cout << "Student: " << s1.getName() << ", ID: " << s1.getID() << ", GPA: " << s1.getGPA() << std::endl;

    // Test scholarship eligibility
    if (s1.isEligibleForScholarship()) {
        std::cout << s1.getName() << " is eligible for a scholarship." << std::endl;
    } else {
        std::cout << s1.getName() << " is not eligible for a scholarship." << std::endl;
    }

    // Test with lower GPA
    s1.setGPA(3.2);
    if (s1.isEligibleForScholarship()) {
        std::cout << s1.getName() << " is eligible for a scholarship." << std::endl;
    } else {
        std::cout << s1.getName() << " is not eligible for a scholarship." << std::endl;
    }

    return 0;
}


int main() {
    // Test default constructor
    Student s1;
    std::cout << "Default student: " << s1.getName() << ", ID: " << s1.getID() << ", GPA: " << s1.getGPA() << std::endl;

    // Test parameterized constructor
    Student s2("Bob Miller", 98765, 3.8);
    std::cout << "Student 2: " << s2.getName() << ", ID: " << s2.getID() << ", GPA: " << s2.getGPA() << std::endl;

    // Test setter methods
    s1.setName("Carol Wilson");
    s1.setID(11111);
    s1.setGPA(3.4);

    // Test getter methods
    std::cout << "Updated student: " << s1.getName() << ", ID: " << s1.getID() << ", GPA: " << s1.getGPA() << std::endl;

    // Test scholarship eligibility
    std::cout << s1.getName() << " scholarship eligibility: " << (s1.isEligibleForScholarship() ? "Yes" : "No") << std::endl;

    std::cout << s2.getName() << " scholarship eligibility: " << (s2.isEligibleForScholarship() ? "Yes" : "No") << std::endl;

    std::cout << "===============================" << std::endl;
    test_class_definition();
    std::cout << "===============================" << std::endl;
    test_constructors();
    std::cout << "===============================" << std::endl;
    test_methods();
    
    return 0;
}
