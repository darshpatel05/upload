// student.h
#ifndef STUDENT_H
#define STUDENT_H

#include <string>

// Student class declaration
class Student {
    // TODO: Add private member variables for student name, ID, and GPA
private:
    std::string name;
    int id;
    double gpa;

public:
    // TODO: Add constructor declarations
    Student();
    Student(std::string name, int id, double gpa);

    // TODO: Add method declarations for getting and setting student information
    std::string getName() const;
    int getID() const;
    double getGPA() const;

    void setName(std::string name);
    void setID(int id);
    void setGPA(double gpa);

    // TODO: Add method to calculate scholarship eligibility (GPA >= 3.5)
    bool isEligibleForScholarship() const;
};

#endif // STUDENT_H
