// student.cpp
#include "student.h"
#include <iostream>

// TODO: Implement constructor(s)
// Default constructor
Student::Student() : name("unknown"), id(0), gpa(0.0) {}

// Parameterized constructor
Student::Student(std::string name, int id, double gpa) : name(name), id(id), gpa(gpa) {}

// TODO: Implement getter and setter methods
// Getters
std::string Student::getName() const {
    return name;
}

int Student::getID() const {
    return id;
}

double Student::getGPA() const {
    return gpa;
}

// Setters
void Student::setName(std::string name) {
    this->name = name;
}

void Student::setID(int id) {
    this->id = id;
}

void Student::setGPA(double gpa) {
    this->gpa = gpa;
}

// TODO: Implement scholarship eligibility method
bool Student::isEligibleForScholarship() const {
    return this->gpa >= 3.5;
}
