#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <iostream>

// TODO: Create a calculator namespace with basic math functions
// and a function to display results
namespace calculator {
    // Basic math functions
    double add(double a, double b);         // Returns a + b
    double subtract(double a, double b);    // Returns a - b
    double multiply(double a, double b);    // Returns a * b
    double divide(double a, double b);      // Return a / b, handles division by zero

    // Function to display result with formatting
    void display_result(const std::string& operation, double a, double b, double result);
}

#endif // CALCULATOR_H
