// main.cpp
#include "calculator.h"
#include <iostream>
#include <iomanip>
#include <limits>

int test_iostream() {
    // Using fully qualified names
    std::cout << "Enter two numbers : ";
    double num1, num2;
    std::cin >> num1 >> num2;

    // Using manipulators for formatting
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Sum : " << num1 + num2 << std::endl;

    // Stream formatting
    std::cout << std::setw(10) << "Number 1 " << std::setw(10) << " Number 2 " << std::endl;
    std::cout << std::setw(10) << num1 << std::setw(10) << num2 << std::endl;

    return 0;
}

void demonstrate_manipulators() {
    double value = 3.14159265359;

    // Precision
    std::cout << "Default: " << value << std::endl;
    std::cout << "Fixed with 2 decimal places: " << std::fixed << std::setprecision(2) << value << std::endl;
    std::cout << "Scientific: " << std::scientific << value << std::endl;

    // Reset format
    std::cout.unsetf(std::ios::fixed | std::ios::scientific);
    std::cout << std::setprecision(6);

    // Width and fill
    std::cout << "Width of 10, right-aligned: |" << std::setw(10) << value << " |" << std::endl;
    std::cout << "Width of 10, left-aligned:  |" << std::left << std::setw(10) << value << " |" << std::endl;
    std::cout << "Width of 10, filled with *: |" << std::right << std::setfill('*') << std::setw(10) << value << " |" << std::endl;

    // Boolean values
    bool flag = true;
    std::cout << "Boolean (default): " << flag << std::endl;
    std::cout << "Boolean (as text): " << std::boolalpha << flag << std::endl;

    // Integer bases
    int num = 255;
    std::cout << "Decimal: " << num << std::endl;
    std::cout << "Hexadecimal: " << std::hex << num << std::endl;
    std::cout << "Octal: " << std::oct << num << std::endl;
}

int main() {
    // TODO: Use calculator namespace functions and demonstrate I/O operations
    std::cout << " Welcome to the Calculator Program! " << std::endl;
    std::cout << " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " << std::endl;

    double a, b;

    // Get user input with error handling
    std::cout << "Enter first number: ";
    while (!(std::cin >> a)) {
        std::cin.clear(); // Clear error flags
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard invalid input
        std::cout << "Invalid input. Please enter a number: ";
    }

    std::cout << "Enter second number: ";
    while (!(std::cin >> b)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Invalid input. Please enter a number: ";
    }

    // Using fully qualified namespace
    double sum = calculator::add(a, b);
    calculator::display_result(" + ", a, b, sum);

    double difference = calculator::subtract(a, b);
    calculator::display_result(" - ", a, b, difference);

    // Using using directive for the next operations
    using namespace calculator;

    double product = multiply(a, b);
    display_result(" * ", a, b, product);

    double quotient = divide(a, b);
    display_result(" / ", a, b, quotient);

    // Demonstrate iostream manipulators
    std::cout << "\nFormatting Examples: " << std::endl;
    std::cout << "===================" << std::endl;

    std::cout << "Scientific notation: " << std::scientific << sum << std::endl;
    std::cout << "Fixed notation (3 decimals): " << std::fixed << std::setprecision(3) << sum << std::endl;
    std::cout << "Right-aligned in field of width 15: |" << std::setw(15) << sum << " |" << std::endl;
    std::cout << "Left-aligned in field of width 15:  |" << std::left << std::setw(15) << sum << " |" << std::endl;

    std::cout << "======================================" << std::endl;
    test_iostream();
    std::cout << "======================================" << std::endl;
    demonstrate_manipulators();

    return 0;
}
