#ifndef COUNTER_H
#define COUNTER_H

class Counter {
private:
    int value;
    static int total_counters; // Static member to track total instances

public:
    // Constructor and destructor
    Counter();  // Default constructor initializes value at 0
    Counter(int initial_value); // Sets the initial value
    ~Counter(); // Destructor

    // Methods
    void increment();   // Increase value by 1
    void decrement();   // Decrease value by 1
    int getValue() const;   // Returns the current value

    // Static method to get total counter instances
    static int getTotalCounters();  // Returns the total number of Counter instances
};

#endif // COUNTER_H
