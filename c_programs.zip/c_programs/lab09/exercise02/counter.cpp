#include "counter.h"
#include <iostream>

// Initialize static member
int Counter::total_counters = 0;

// TODO: Implement constructor(s) to track total instances
// Default Constructor
Counter::Counter() : value(0) {
    total_counters++;
}

// Parameterized Constructor
Counter::Counter(int initial_value) : value(initial_value) {
    total_counters++;
}

// TODO: Implement destructor to update total instances
Counter::~Counter() {
    total_counters--;
}

// TODO: Implement getter / setter methods
void Counter::increment() {
    this->value++;
}

void Counter::decrement() {
    this->value--;
}

int Counter::getValue() const {
    return this->value;
}

// TODO: Implement static method
int Counter::getTotalCounters() {
    return Counter::total_counters;
}
