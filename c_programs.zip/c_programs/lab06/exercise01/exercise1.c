//GPT logs: https://chatgpt.com/share/67cbcccf-5454-8013-98fe-66334b5293ee
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Your implementation should include these functions:

// Tokenize a string and store tokens in a dynamically allocated array
// Returns the number of tokens found
// tokens will be a dynamically allocated array of dynamically allocated strings
int tokenize_string(const char *str, char delimiter, char ***tokens);

// Filter strings containing a specific substring
// Returns the number of strings in the filtered array
// filtered will be a dynamically allocated array of dynamically allocated strings
int filter_strings(char **strings, int count, const char *substring, char ***filtered);

// Join an array of strings with a delimiter
// Returns a newly allocated string containing the joined result
char *join_strings(char **strings, int count, const char *delimiter);

// Helper function to free an array of strings
void free_string_array(char **strings, int count);

int main() {
    int array_size = 6;
    char** strings = (char**)malloc(array_size * sizeof(char*));

    if (strings == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    for (int i = 0; i < array_size; i++) {
        strings[i] = (char *)malloc(6 * sizeof(char));
        if (strings[i] == NULL) {
            printf("Memory allocation failed!\n");
            return 1;
        }
    }

    strcpy(strings[0], "Hello");
    strcpy(strings[1], "world");
    strcpy(strings[2], "this");
    strcpy(strings[3], "is");
    strcpy(strings[4], "a");
    strcpy(strings[5], "test");


    char* str = (char*)malloc(21 * sizeof(char));
    char delimiter = ',';
    char** tokens = NULL;

    printf("\nTokenize Strings Function Test:\n");
    int num_tokens = tokenize_string(str, delimiter, &tokens);
    printf("Number of tokens: %d\n", num_tokens);
    for(int i = 0; i < num_tokens; i++) {
        printf("%s\n", *tokens[i]);
    }

    int count = 5;
    char** array = (char**)malloc(count * sizeof(char*));
    char* sub = "ap";
    char** filtered = NULL;

    printf("\nFiltered Strings Function Test:\n");
    int num_matches = filter_strings(array, 5,  sub, &filtered);
    printf("Number of matches: %d\n", num_matches);
    for(int i = 0; i < num_matches; i++) {
        printf("%s\n", *filtered[i]);
    }

    printf("\nOriginal:\n");
    for(int i = 0; i < array_size; i++) {
        printf("%s\n", *(strings + i));
    }

    printf("\nJoin Strings Function Test:\n");
    char* joint = join_strings(strings, array_size, ",");
    printf("%s\n", joint);
    
    return 0;
}

int tokenize_string(const char *str, char delimiter, char ***tokens) {
    int num_tokens = 1;

    for(int i = 0; i < strlen(str); i++) {
        if(str[i] == delimiter) {
            num_tokens++;
        }
    }

    *tokens = malloc(num_tokens * sizeof(char*));
    if (*tokens == NULL) {
        printf("Memory allocation failed!\n");
        return 1; 
    }

    int index = 0;
    for(int i = 0; i < num_tokens; i++) {
        for(int j = 0; j < strlen(str); j++) {
            
            if(str[i] == delimiter) {
                index++;
            } else {
                *(tokens[index]) = str[i];
            }
        }
    }
    return num_tokens;
}

int filter_strings(char **strings, int count, const char *substring, char ***filtered) {
    int num_matches = 0;

    for(int i = 0; i < count; i++) {
        if(strstr(strings[i], substring) != NULL) {
            num_matches++;
        }
    }
    
    *filtered = (char**)malloc(num_matches * sizeof(char*));
    if (*filtered == NULL) {
        printf("Memory allocation failed!\n");
        return 0; 
    }

    int index = 0;
    for(int i = 0; i < count; i++) {
        if(strstr(strings[i], substring) != NULL) {
            *(filtered[index]) = strings[i];
            index++;
        }
    }
    return num_matches;
}

char *join_strings(char **strings, int count, const char *delimiter) {
    // Dynamic Allocation of memory for joint string
    char* joint_string = malloc(sizeof(char*) * count);

    // Traversing through array, concating the string together with the delimiter
    for(int i = 0; i < count; i++) {
        joint_string = strcat(joint_string, strings[i]);

        // Does not concat delimiter after last string
        if(i < count - 1) {
            joint_string = strcat(joint_string, delimiter);
        }
    }

    return joint_string;
}

void free_string_array(char **strings, int count) {
    // Checks if the array is empty
    if(strings == NULL) {
        return;
    }

    // Frees the columns of each row before clearing the initial row to ensure there isn't a memory leak
    for(int i = 0; i < count; i++) {
        free(strings[i]);
    }

    // Frees the initial row
    free(strings);
}