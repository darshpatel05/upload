#include <stdio.h>
#include <stdlib.h>

// Create a dynamically allocated 2D array
// Returns a pointer to the allocated array, or NULL if allocation fails
int **create_2d_array(int rows, int cols, int init_value);

// Free a dynamically allocated 2D array
void free_2d_array(int **array, int rows);

// Resize a dynamically allocated 2D array
// Returns a pointer to the resized array, or NULL if allocation fails
// The original array is freed if the resize operation succeeds
// The original array remains unchanged if the resize operation fails
int **resize_2d_array(int **array, int old_rows, int old_cols, int new_rows, int new_cols, int fill_value);

// Helper function to print a 2D array (for testing)
void print_2d_array(int **array, int rows, int cols);


int main() {
    printf("\nOriginal Array:\n");
    int** array = create_2d_array(3, 3, 5);
    print_2d_array(array, 3, 3);
    
    printf("\nResized Array:\n");
    array = resize_2d_array(array, 3, 3, 5, 5, 6);
    print_2d_array(array, 5, 5);

    return 0;
}

int **create_2d_array(int rows, int cols, int init_values) {
    // Dynamically allocates memory of the specifies size
    int** array = (int**)malloc(rows * sizeof(int*));
    for(int i = 0; i < rows; i++) {
        array[i] = (int*)malloc(cols * sizeof(int));

        // Checks if the array is empty
        if(array[i] == NULL) {
            // Frees the columns of each row before clearing the initial row to ensure there isn't a memory leak
            for(int j = 0; j < i; j++) {
                free(array[j]);
            }
            // Frees the initial row
            free(array);
            return NULL;
        }
    }
    // Initializes the array with the specified value
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            array[i][j] = init_values;
        }
    }
    return array;
}

void free_2d_array(int **array, int rows) {
    // Checks if the array is empty
    if(array == NULL) {
        return;
    }

    // Frees the columns of each row before clearing the initial row to ensure there isn't a memory leak
    for(int i = 0; i < rows; i++) {
        free(array[i]);
    }

    // Frees the initial row
    free(array);
}

int **resize_2d_array(int** array, int old_rows, int old_cols, int new_rows, int new_cols, int fill_value) {
    // Reallocates memory for the new rows and columns
    array = realloc(array, new_rows * sizeof(int*));
    for(int i = 0; i < new_rows; i++) {
        array[i] = realloc(array[i], new_cols * sizeof(int));
        // Checks if the array is empty
        if(array[i] == NULL) {
            // Frees the columns of each row before clearing the initial row to ensure there isn't a memory leak
            for(int j = 0; j < i; j++) {
                free(array[j]);
            }
            // Frees the initial row
            free(array);
            return NULL;
        }
    }
    // Initializes the values provided in the new rows and columns
    for(int i = 0; i < new_rows; i++) {
        for(int j = 0; j < new_cols; j++) {
            if(i >= old_rows || j >= old_cols) {
                array[i][j] = fill_value;
            }
        }
    }
    return array;
}

void print_2d_array(int **array, int rows, int cols) {
    // Traverses through array and prints individual elements in a matrix format
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            printf("%d ", array[i][j]);
        }
        printf("\n");
    }
}