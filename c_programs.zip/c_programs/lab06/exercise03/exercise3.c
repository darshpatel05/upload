#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Constants for string transformation types
#define TRANSFORM_UPPERCASE 0
#define TRANSFORM_LOWERCASE 1
#define TRANSFORM_REVERSE 2

// Sort an array of strings in lexicographical order
// The original strings are not modified, only the pointers are rearranged
void sort_strings(char **strings, int count);

// Remove duplicate strings from an array
// Returns the new size of the array after removing duplicates
// The original array is modified in place
int remove_duplicates(char **strings, int count);

// Transform strings according to the specified transformation type
// Returns a new array of transformed strings
// The original strings are not modified
char **transform_strings(char **strings, int count, int transform_type);

// Helper function to free an array of strings
void free_string_array(char **strings, int count);

int main() {
    // Dynamically Allocating memory for string array
    int array_size = 7;
    char** strings = (char**)malloc(array_size * sizeof(char*));
    // Checks if the array is empty
    if (strings == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }
    // Checks specific elements to see if they are empty
    for (int i = 0; i < array_size; i++) {
        strings[i] = (char *)malloc(array_size * sizeof(char));
        if (strings[i] == NULL) {
            printf("Memory allocation failed!\n");
            return 2;
        }
    }

    strcpy(strings[0], "bannana");
    strcpy(strings[1], "apple");
    strcpy(strings[2], "bannana");
    strcpy(strings[3], "orange");
    strcpy(strings[4], "grape");
    strcpy(strings[5], "orange");
    strcpy(strings[6], "kiwi");
    
    printf("Original:\n");
    for(int i = 0; i < array_size; i++) {
        printf("%s\n", *(strings + i));
    }

    
    printf("\nSorted Strings:\n");
    sort_strings(strings, array_size);
    for(int i = 0; i < array_size; i++) {
        printf("%s\n", strings[i]);
    }

    printf("\nNon-Duplicate Strings:\n");
    int size = remove_duplicates(strings, array_size);
    for(int i = 0; i < size; i++) {
        printf("%s\n", strings[i]);
    }

    printf("\nUppercase Strings:\n");
    transform_strings(strings, array_size, 0);
    for(int i = 0; i < array_size; i++) {
        printf("%s\n", strings[i]);
    }

    printf("\nLowercase Strings:\n");
    transform_strings(strings, array_size, 1);
    for(int i = 0; i < array_size; i++) {
        printf("%s\n", strings[i]);
    }

    printf("\nReversed Strings:\n");
    transform_strings(strings, array_size, 2);
    for(int i = 0; i < array_size; i++) {
        printf("%s\n", strings[i]);
    }
    
    return 0;
}

void sort_strings(char **strings, int count) {
    char* temp;
    for(int i = 0; i < count; i++) {
        for(int j = 0; j < count; j++) {
            if(strcmp(strings[i], strings[j]) < 0) {
                temp = strings[i];
                strings[i] = strings[j];
                strings[j] = temp;
            }
        }
    }
}

int remove_duplicates(char **strings, int count) {
    int numDuplicates = 0;
    for(int i = count - 1; i > 0; i--) {
        for(int j = i - 1; j > -1; j--) {
            if(strcmp(strings[i], strings[j]) == 0) {
                numDuplicates++;
                for(int m = i; m < count - 1; m++) {
                    strings[m] = strings[m + 1];
                }
                strings[count - numDuplicates] = "\0";
            }
        }
    }
    return count - numDuplicates;
}

char **transform_strings(char **strings, int count, int transform_type) {
    if(transform_type == TRANSFORM_UPPERCASE) {
        for(int i = 0; i < count; i++) {
            for(int j = 0; j < strlen(strings[i]); j++) {
                if(strings[i][j] >= 'a' && strings[i][j] <= 'z') {
                    strings[i][j] = strings[i][j] - 32;
                }
            }
        }
    } else if(transform_type == TRANSFORM_LOWERCASE) {
        for(int i = 0; i < count; i++) {
            for(int j = 0; j < strlen(strings[i]); j++) {
                if(strings[i][j] >= 'A' && strings[i][j] <= 'Z') {
                    strings[i][j] = strings[i][j] + 32;
                }
            }
        }
    } else if(transform_type == TRANSFORM_REVERSE) {
        char temp;
        for(int i = 0; i < count; i++) {
            for(int j = 0; j < strlen(strings[i]) / 2; j++) {
                temp = strings[i][j];
                strings[i][j]  = strings[i][strlen(strings[i]) - j -1];
                strings[i][strlen(strings[i]) - j -1] = temp;
            }
        } 
    }
    return strings;
}

void free_string_array(char **strings, int count) {
    // Checks if the array is empty
    if(strings == NULL) {
        return;
    }

    // Frees the columns of each row before clearing the initial row to ensure there isn't a memory leak
    for(int i = 0; i < count; i++) {
        free(strings[i]);
    }

    // Frees the initial row
    free(strings);
}