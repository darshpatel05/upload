#include <stdio.h>

int main() {    // naming convention for functions in C is to have the first letter be lowercase
    int number = 42;    // The 'I' in Int should have been lowercase
    float decimal = 3.14; // Missing semicolon
    char letter = 'A';  // Char uses single quotes


    printf("Number: %d\n", number); // The 'P' in the Printf should have been lowercase, and the specifier for float (%f) was used as opposed to the specifier for int (%d)
    printf("Decimal: %d\n", decimal);
    printf("Letter: %c\n", letter); // The specifier for string (%s) was used as opposed to the specifier for int (%c)
    return 0;   // Missing semicolon
}