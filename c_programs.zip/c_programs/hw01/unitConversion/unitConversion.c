#include <stdio.h>

// Function Signatures
float miles_to_kilometers(float miles);     // Function to convert miles to kilometers
float feet_to_meters(float feet);           // Function to convert feet to meters
float inches_to_centimeters(float inches);  // Function to convert inches to centimeters

const float kilometersPerMile = 1.60934;    // Variable initialization for kilometers to miles conversion value
const float metersPerFoot = 0.3048;         // Variable initialization for meters to feet conversion value
const float centimetersPerInch = 2.54;      // Variable initialization for centimeters to inches conversion value

int main(void) {
    float miles, feet, inches;  // Variable declaration

    printf("Enter distance in miles: ");
    scanf("%f", &miles);
    printf("%.2f miles = %.2f kilometers\n", miles, miles_to_kilometers(miles));
    printf("\nEnter distance in feet: ");
    scanf("%f", &feet);
    printf("%.2f feet = %.2f meters\n", miles, feet_to_meters(feet));
    printf("\nEnter distance in inches: ");
    scanf("%f", &inches);
    printf("%.2f inches = %.2f centimeters\n", inches, inches_to_centimeters(inches));
    
    return 0;
}

float miles_to_kilometers(float miles) {
    return miles * kilometersPerMile;
}

float feet_to_meters(float feet) {
    return feet * metersPerFoot;
}

float inches_to_centimeters(float inches) {
    return inches * centimetersPerInch;
 }