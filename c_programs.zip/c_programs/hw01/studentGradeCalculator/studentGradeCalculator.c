#include <stdio.h>

int main(void) {
    float hw1, hw2, hw3, test1, test2, final;   // Variable declaration for the individual grades - to be inputted by the user
   
    // Prompting user for individual homework grades
    printf("Enter grade for homework 1: ");
    scanf("%f", &hw1);
    printf("Enter grade for homework 2: ");
    scanf("%f", &hw2);
    printf("Enter grade for homework 3: ");
    scanf("%f", &hw3);

    // Prompting user for individual test grades
    printf("Enter grade for test 1: ");
    scanf("%f", &test1);
    printf("Enter grade for test 2: ");
    scanf("%f", &test2);

    //Prompting user for final exam grade
    printf("Enter grade for final exam: ");
    scanf("%f", &final);

    float avgHW = (hw1 + hw2 + hw3) / 3;    // Initializing a variable for the average homework grades
    float avgTest = (test1 + test2) / 2;    // Initializing a variable for the average test grades
   
    float weightedHW = avgHW * 0.3;         // Initializing a variable for the weighted homework grade
    float weightedTest = avgTest * 0.4;     // Initializing a variable for the weighted test grade
    float weightedFinal = final * 0.3;      // Initializing a variable for the weighted final exam grade

    float finalGrade = weightedHW + weightedTest + weightedFinal;   // Initializing a variable for the final weighted grade

    // Formatted Output
    printf("\nHomework Grades: %.2f, %.2f, %.2f\n", hw1, hw2, hw3);
    printf("Average Homework: %.2f (Weight: 30%%)\n", avgHW);
    printf("Test Grades: %.2f, %.2f\n", test1, test2);
    printf("Average Test: %.2f (Weight: 40%%)\n", avgTest);
    printf("Final Exam: %.2f (Weight: 30%%)\n", final);
    printf("\nFinal Grade: %.2f\n", finalGrade);

    return 0;
}