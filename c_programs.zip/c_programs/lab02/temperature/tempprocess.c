#include <stdio.h>

// Temperature thresholds (matching lecture examples)
const int MAX_TEMP = 100;   // Maximum allowed temperature
const int MIN_TEMP = 0;     // Minimum allowed temperature

// Function to process temperatures
void process_temperature(void) {
    float temp1, temp2, temp3, temp4, temp5;
    float sum;  // Uninitialized variable

    // Bug 1: Infinite Loop
    /*
    - Added an input buffer that checks whether the inputs are valid, and if not, continuously prompts the user to add a valid temperature value
    - Added the missing scanf statement and the missing count increment statement
    */
    int count = 1;
    while (count <= 5) {
        // Input buffer that verifies whether the input is valid
        int buffer;
        float temp_val;
        do{
            printf("Enter temperature %d: ", count);
            buffer = scanf("%f", &temp_val);
            if (buffer != 1) {
                printf("Invalid Input!\n");
                while (getchar() != '\n');
            }
        } while (buffer != 1);

        if (count == 1) {
            temp1 = temp_val;
        } else if (count == 2) {
            temp2 = temp_val;
        } else if (count == 3) {
            temp3 = temp_val;
        } else if (count == 4) {
            temp4 = temp_val;
        } else {
            temp5 = temp_val;
        }

        count++;    // Count increment statement to prevent infinite loop
    }

    // Bug 2: Uninitialized Variable Usage
    /*
    - Initialized the previously declared variable sum by adding all the individual temperature variables
    */
    sum = temp1 + temp2 + temp3 + temp4 + temp5;
    printf("Sum of temperatures: %.2f\n", sum);

    // Bug 3: Logic Error in Temperature Check
    /*
    - Fixed the logical operators from logical OR '||' to logical AND '&&'
    - Added an else statement to each established if block that prints when the temperature is out of range
    */
    if (temp1 > MIN_TEMP && temp1 < MAX_TEMP) {
        printf("Temperature 1 is in range\n");
    } else {
        printf("Temperature 1 is out of range\n");
    }

    if (temp2 > MIN_TEMP && temp2 < MAX_TEMP) {
        printf("Temperature 2 is in range\n");
    } else {
        printf("Temperature 2 is out of range\n");
    }

    if (temp3 > MIN_TEMP && temp3 < MAX_TEMP) {
        printf("Temperature 3 is in range\n");
    } else {
        printf("Temperature 3 is out of range\n");
    }

    if (temp4 > MIN_TEMP && temp4 < MAX_TEMP) {
        printf("Temperature 4 is in range\n");
    } else {
        printf("Temperature 4 is out of range\n");
    }

    if (temp5 > MIN_TEMP && temp5 < MAX_TEMP) {
        printf("Temperature 5 is in range\n");
    } else {
        printf("Temperature 5 is out of range\n");
    }

    // Bug 4: Incorrect Average Calculation
    /*
    - Fixed the average variable initialization by dividing the sum by 5 for the average
    */
    float average = sum / 5;
    printf("Average temperature: %.2f\n", average);
}

int main(void) {
    process_temperature();
    return 0;
}