#include <stdio.h>

// Global temperature threshold
int MAX_TEMP = 100;     // Maximum allowed temperature
int MIN_TEMP = 0;       // Minimum allowed temperature
/*
Both variables have a global scope - meaning their values are accessible throughout the program unless the variables have been shadowed within a smaller scope with a higher priority.
*/

int main(void) {
    // Local temperature variables
    int current_temp = 75;
    int is_valid = 0;       // Flag for temperature validity
    /*
    These variables are defined with a function scope - meaning that their values are only accessible throughout the main function.
    */
    do {
        // Input buffer that verifies whether the user had inputted a valid value that can be stored in the proposed variable
        printf("Enter temperature: ");
        int buffer = scanf("%d", &current_temp);
        if (buffer != 1) {
            printf("Input Error!\n");
            break;
        }

        // Check if temperature is in valid range
        if (current_temp <= 150 && current_temp >= -50) {
            is_valid = 1;
            // Check if temperature is within the maximum and minimum allowed range
            if (current_temp <= MAX_TEMP && current_temp >= MIN_TEMP) {
                printf("Temperature %d is in valid range (%d - %d)\n", current_temp, MIN_TEMP, MAX_TEMP);
            } else if (current_temp > MAX_TEMP) {
                printf("Warning: Temperature %d is above maximum (%d)\n", current_temp, MAX_TEMP);
            } else {
                printf("Warning: Temperature %d is below minimum (%d)\n", current_temp, MIN_TEMP);
            }
        } else {
            printf("Warning: Temperature %d is out of range!\n", current_temp);
        }

        // Block demonstrating variable shadowing
        {
            int MAX_TEMP = 80;  // Shadows global MAX_TEMP
            /*
            The MAX_TEMP variable initialized in the previous line has its scope within the block and is shadowing the previously initialized version of the variable MAX_TEMP, which has a global scope. To specify, variable shadowing is when two variables of the same name are initialized but can store different values due to the level of their scope. In this case, the MAX_TEMP variable initialized in the previous line takes priority as its scope is the block, whereas the other initialization was at the global level.
            */
            printf("Local MAX_TEMP : %d\n", MAX_TEMP);
        }
        printf("Global MAX_TEMP: %d\n", MAX_TEMP);

    } while (!is_valid);

    return 0;
}