#include <stdio.h>

// Temperature thresholds (matching lecture examples)
const int MAX_TEMP = 100;   // Maximum allowed temperature
const int MIN_TEMP = 0;     // Minimum allowed temperature

int main(void) {
    int choice, buffer;
    float temp1, temp2, temp3, temp4, temp5;    // Individual temperature variables
    
    do {
        // Display menu
        printf("\nTemperature Monitor Menu:\n");
        printf("1. Enter temperatures\n");
        printf("2. Check temperature status\n");
        printf("3. Display statistics\n");
        printf("4. Exit\n");

        /*
        - Added an input buffer for the choice operation to prevent invalid inputs
        */
        do{
            printf("Enter choice: ");
            buffer = scanf("%d", &choice);
            if (buffer != 1) {
                printf("Invalid Input!\n");
                while (getchar() != '\n');
            }
        } while (buffer != 1);

        switch (choice) {
            case 1:
                // TODO: Add input validation
                /*
                - Each do-while statement verifies that the user has inputted a valid value for temp and if that value for temperature is within a valid range
                */
                do{
                    printf("Enter temperature 1: ");
                    buffer = scanf("%f", &temp1);
                    if (buffer != 1) {
                        printf("Invalid Input!\n");
                        while (getchar() != '\n');
                    } else if (150 < temp1 || -50 > temp1) {
                        printf("Invalid Temperature!\n");
                    }
                } while (buffer != 1 || (150 < temp1 || -50 > temp1));

                do{
                    printf("Enter temperature 2: ");
                    buffer = scanf("%f", &temp2);
                    if (buffer != 1) {
                        printf("Invalid Input!\n");
                        while (getchar() != '\n');
                    } else if (temp2 > 150 || temp2 < -50) {
                        printf("Invalid Temperature!\n");
                    }
                } while (buffer != 1 || (temp2 > 150 || temp2 < -50));

                do{
                    printf("Enter temperature 3: ");
                    buffer = scanf("%f", &temp3);
                    if (buffer != 1) {
                        printf("Invalid Input!\n");
                        while (getchar() != '\n');
                    } else if (temp3 > 150 || temp3 < -50) {
                        printf("Invalid Temperature!\n");
                    }
                } while (buffer != 1 || (temp3 > 150 || temp3 < -50));

                do{
                    printf("Enter temperature 4: ");
                    buffer = scanf("%f", &temp4);
                    if (buffer != 1) {
                        printf("Invalid Input!\n");
                        while (getchar() != '\n');
                    } else if (temp4 > 150 || temp4 < -50) {
                        printf("Invalid Temperature!\n");
                    }
                } while (buffer != 1 || (temp4 > 150 || temp4 < -50));

                do{
                    printf("Enter temperature 5: ");
                    buffer = scanf("%f", &temp5);
                    if (buffer != 1) {
                        printf("Invalid Input!\n");
                        while (getchar() != '\n');
                    } else if (temp5 > 150 || temp5 < -50) {
                        printf("Invalid Temperature!\n");
                    }
                } while (buffer != 1 || (temp5 > 150 || temp5 < -50));

                break;
            
            case 2:
                // TODO: Add temperature range checking
                /*
                - Checks the range that each temperature value falls into and provides a corresponding message
                */
                if (MAX_TEMP >= temp1 && MIN_TEMP <= temp1) {
                    printf("Temperature %.1f is in valid range (%d - %d)\n", temp1, MAX_TEMP, MIN_TEMP);
                } else if (MAX_TEMP < temp1) {
                    printf("Warning: Temperature %.1f is above maximum (%d)\n", temp1, MAX_TEMP);
                } else {
                    printf("Warning: Temperature %.1f is below minimum (%d)\n", temp1, MIN_TEMP);
                }
                
                if (MAX_TEMP >= temp2 && MIN_TEMP <= temp2) {
                    printf("Temperature %.1f is in valid range (%d - %d)\n", temp2, MAX_TEMP, MIN_TEMP);
                } else if (MAX_TEMP < temp2) {
                    printf("Warning: Temperature %.1f is above maximum (%d)\n", temp2, MAX_TEMP);
                } else {
                    printf("Warning: Temperature %.1f is below minimum (%d)\n", temp2, MIN_TEMP);
                }

                if (MAX_TEMP >= temp3 && MIN_TEMP <= temp3) {
                    printf("Temperature %.1f is in valid range (%d - %d)\n", temp3, MAX_TEMP, MIN_TEMP);
                } else if (MAX_TEMP < temp3) {
                    printf("Warning: Temperature %.1f is above maximum (%d)\n", temp3, MAX_TEMP);
                } else {
                    printf("Warning: Temperature %.1f is below minimum (%d)\n", temp3, MIN_TEMP);
                }

                if (MAX_TEMP >= temp4 && MIN_TEMP <= temp4) {
                    printf("Temperature %.1f is in valid range (%d - %d)\n", temp4, MAX_TEMP, MIN_TEMP);
                } else if (MAX_TEMP < temp4) {
                    printf("Warning: Temperature %.1f is above maximum (%d)\n", temp4, MAX_TEMP);
                } else {
                    printf("Warning: Temperature %.1f is below minimum (%d)\n", temp4, MIN_TEMP);
                }

                if (MAX_TEMP >= temp5 && MIN_TEMP <= temp5) {
                    printf("Temperature %.1f is in valid range (%d - %d)\n", temp5, MAX_TEMP, MIN_TEMP);
                } else if (MAX_TEMP < temp5) {
                    printf("Warning: Temperature %.1f is above maximum (%d)\n", temp5, MAX_TEMP);
                } else {
                    printf("Warning: Temperature %.1f is below minimum (%d)\n", temp5, MIN_TEMP);
                }
                break;

            case 3:
                // TODO: Add statistics calculation
                /*
                - Added the max and min statistic that is determined via multiple if statements that compare each temperature value to the preset max or min value
                - Added the average statistic by finding the sum of all the temperatures and dividing by the total number of temperatures
                - Added the number of valid temperatures by using a count variable that incremented each time an if statement verified if a temperature value was in range
                */
                float max_temp = temp1;
                if (max_temp < temp2) {
                    max_temp = temp2;
                } if (max_temp < temp3) {
                    max_temp = temp3;
                } if (max_temp < temp4) {
                    max_temp = temp4;
                } if (max_temp < temp5) {
                    max_temp = temp5;
                }
                
                float min_temp = temp1;
                if (min_temp > temp2) {
                    min_temp = temp2;
                } if (min_temp > temp3) {
                    min_temp = temp3;
                } if (min_temp > temp4) {
                    min_temp = temp4;
                } if (min_temp > temp5) {
                    min_temp = temp5;
                }
                
                float avg = (temp1 + temp2 + temp3 + temp4 + temp5) / 5;
                
                int count = 0;
                if (MAX_TEMP >= temp1 && MIN_TEMP <= temp1) {
                    count++;
                } if (MAX_TEMP >= temp2 && MIN_TEMP <= temp2) {
                    count++;
                } if (MAX_TEMP >= temp3 && MIN_TEMP <= temp3) {
                    count++;
                } if (MAX_TEMP >= temp4 && MIN_TEMP <= temp4) {
                    count++;
                } if (MAX_TEMP >= temp5 && MIN_TEMP <= temp5) {
                    count++;
                }
                
                printf("Maximum temperature is %.1f\n", max_temp);
                printf("Minimum temperature is %.1f\n", min_temp);
                printf("Average temperature is %.1f\n", avg);
                printf("# of valid temperature(s) are %d\n", count);

                break;

            case 4:
                printf("Exiting program.\n");
                break;
            
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}