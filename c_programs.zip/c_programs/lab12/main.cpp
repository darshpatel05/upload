#include <iostream>
#include "vector.cpp"

int main() {
    // Test numeric vectors
    Vector<int> v1(3);
    v1[0] = 1; v1[1] = 2; v1[2] = 3;

    Vector<int> v2(3);
    v2[0] = 4; v2[1] = 5; v2[2] = 6;

    auto v3 = v1 + v2;
    v3 *= 2;

    std::cout << "v1: ";
    for (size_t i = 0; i < v1.getSize(); ++i) {
        std::cout << v1[i] << " ";
    }
    std::cout << "\n";

    std::cout << "v2: ";
    for (size_t i = 0; i < v2.getSize(); ++i) {
        std::cout << v2[i] << " ";
    }
    std::cout << "\n";

    std::cout << "v3: ";
    for (size_t i = 0; i < v3.getSize(); ++i) {
        std::cout << v3[i] << " ";
    }
    std::cout << "\n";

    // Test boolean vectors
    Vector<bool> bv1(10);
    bv1[0] = true;
    bv1[1] = false;
    bv1[2] = true;

    Vector<bool> bv2(10);
    bv2[0] = true;
    bv2[1] = true;
    bv2[2] = false;

    auto bv3 = bv1 + bv2; // Should perform logical OR

    return 0;
}
