#include <iostream>

template <typename T>
class Vector
{
private:
    T *data;
    size_t size;

public:
    Vector(size_t size = 0) : size(size)
    {
        data = new T[size];
        for (size_t i = 0; i < size; i++)
        {
            data[i] = T{};
        }
    }

    Vector(const Vector &other) : size(other.size)
    {
        data = new T[size];
        for (size_t i = 0; i < size; i++)
        {
            data[i] = other.data[i];
        }
    }

    ~Vector()
    {
        delete[] data;
    }

    T &operator[](size_t index)
    {
        if (index >= size)
        {
            throw std::out_of_range("Error: index out of bounds");
        }
        return data[index];
    }

    const T &operator[](size_t index) const
    {
        if (index >= size)
        {
            throw std::out_of_range("Error: index out of bounds");
        }
        return data[index];
    }

    size_t getSize() const
    {
        return size;
    }

    Vector<T> &operator=(const Vector &other)
    {
        if (this != &other)
        {
            delete[] data;
            size = other.size;
            data = new T[size];
            for (size_t i = 0; i < size; i++)
            {
                data[i] = other.data[i];
            }
        }

        return *this;
    }

    Vector<T> operator+(const Vector<T> &other) const
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        Vector<T> result(size);

        for (size_t i = 0; i < size; i++)
        {
            result.data[i] = data[i] + other.data[i];
        }

        return result;
    }

    Vector<T> operator-(const Vector<T> &other) const
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        Vector<T> result(size);

        for (size_t i = 0; i < size; i++)
        {
            result.data[i] = data[i] - other.data[i];
        }

        return result;
    }

    Vector<T> operator*(const T &value) const
    {
        Vector<T> result(size);

        for (size_t i = 0; i < size; i++)
        {
            result.data[i] = data[i] * value;
        }

        return result;
    }

    bool operator==(const Vector &other)
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        for (size_t i = 0; i < size; i++)
        {
            if (data[i] != other.data[i])
            {
                return 0;
            }
        }

        return 1;
    }

    bool operator!=(const Vector &other)
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        for (size_t i = 0; i < size; i++)
        {
            if (data[i] != other.data[i])
            {
                return 1;
            }
        }

        return 0;
    }

    Vector<T> &operator+=(const Vector &other)
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        for (size_t i = 0; i < size; i++)
        {
            data[i] += other.data[i];
        }

        return *this;
    }

    Vector<T> &operator-=(const Vector &other)
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        for (size_t i = 0; i < size; i++)
        {
            data[i] -= other.data[i];
        }

        return *this;
    }

    Vector<T> &operator*=(const T &value)
    {
        for (size_t i = 0; i < size; i++)
        {
            data[i] *= value;
        }

        return *this;
    }

    friend std::ostream &operator<<(std::ostream &os, const Vector &rhs)
    {
        for (size_t i = 0; i < rhs.size; i++)
        {
            os << rhs.data[i] << " ";
        }
        os << "\n";

        return os;
    }
};

template <>
class Vector<bool>
{
private:
    unsigned char *data;
    size_t size;
    static const size_t BITS_PER_BYTE = 8;

    bool getBit(size_t index)
    {
        size_t byte = index / BITS_PER_BYTE;
        size_t bit = index % BITS_PER_BYTE;

        return (data[byte] >> bit) & 1;
    }

    void setBit(size_t index, bool value)
    {
        size_t byte = index / BITS_PER_BYTE;
        size_t bit = index % BITS_PER_BYTE;

        if (value)
        {
            data[byte] |= (1 << bit);
        }
        else
        {
            data[byte] &= ~(1 << bit);
        }
    }

public:
    Vector(size_t size = 0) : size(size)
    {
        data = new unsigned char[size];
        for (size_t i = 0; i < size; i++)
        {
            data[i] = bool{};
        }
    }

    Vector(const Vector &other) : size(other.size)
    {
        data = new unsigned char[size];
        for (size_t i = 0; i < size; i++)
        {
            data[i] = other.data[i];
        }
    }

    bool operator[](size_t index)
    {
        if (index >= size)
        {
            throw std::out_of_range("Error: index out of bounds");
        }
        return getBit(index);
    }

    size_t getSize() const
    {
        return size;
    }

    bool &operator=(const bool &value)
    {
        return value;
    }

    Vector<bool> operator+(const Vector<bool> &other) const
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        Vector<bool> result(size);

        for (size_t i = 0; i < size; i++)
        {
            result.data[i] = data[i] | other.data[i];
        }

        return result;
    }

    Vector<bool> operator*(const Vector<bool> &other) const
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        Vector<bool> result(size);

        for (size_t i = 0; i < size; i++)
        {
            result.data[i] = data[i] & other.data[i];
        }

        return result;
    }

    Vector<bool> &operator+=(const Vector<bool> &other)
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        for (size_t i = 0; i < size; i++)
        {
            data[i] = data[i] | other.data[i];
        }

        return *this;
    }

    Vector<bool> &operator*=(const Vector<bool> &other)
    {
        if (size != other.size)
        {
            throw std::out_of_range("Error: different vector sizes");
        }

        for (size_t i = 0; i < size; i++)
        {
            data[i] = data[i] & other.data[i];
        }

        return *this;
    }
};